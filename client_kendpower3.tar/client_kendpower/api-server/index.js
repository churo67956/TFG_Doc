const path = require('path')
const express = require("express");
const history = require('connect-history-api-fallback');

const app = express();
app.use(express.json());


app.post('/api/ubus', (req, res) => {
  payload=req.body;
  console.log(payload)
  if ( payload.params[1] === "session" ){
    //res.send("ddf");
    res.send({
      jsonrpc:"2.0",
      id: 1,
      result: [
        0,
        {
          ubus_rpc_session: "528bb388e9cc73ebe22941509ef14027",
          timeout: 300,
          expires: 300,
          acls: {
            "access-group": {
              movilrpcduser: ["read"]
            },
            ubus: {
              wizard:["*"]
            }
          },
          data:{
            username: "moile"
          }
        }
      ]
    });
  }
  else{
    if (payload.params[0] === "528bb388e9cc73ebe22941509ef14027"){
      res.send({
        "jsonrpc": "2.0",
        "id":1,
        "result": [ 
          0,
          {
            "common":{
              "ac_credit_card_status": "true",
              "active_view": "DC2",
              "backend_enabled": "true",
              "charging_point_id": "6Z05172A0010",
              "connectors_layout": "CCSL_CCSR_LAYOUT",
              "credit_card": "true",
              "dc2_credit_card_status": "true",
              "dc_credit_card_status": "true",
              "rapid1xx_enabled": "true",
              "rfid_enabled": "false",
              "swUpdateText": "undefined"
            },
            "view":{
              "credit": "26",
              "cumulative_cost": "0",
              "current": "20.765999972820282",
              "energy": "13",
              "final_cost": "0",
              "fsm_state": "charging",
              "local_identifier": "undefined",
              "logical_connector": "ccsleft",
              "physical_connector": "ccsleft",
              "power": "60",
              "soc": "50",
              "voltage": "400"
            }
          }
        ]
      });
    }
    else{
     let randomInt = Math.floor(Math.random() * (1 - 0) + 0);
     if (randomInt){
      res.send({
        "jsonrpc":"2.0",
        "id":1,
        "error":{
          "code":-32002,
          "message":"Access denied"
        }});
     }
     else{
      res.send({"jsonrpc":"2.0","id":1,"result":[6]});
     }
    }
  }
});




app.post('/api/cart', (req, res) =>
  setTimeout(() => res.status(201).send(), 800)
);

app.post('/api/sign-in', (req, res) => res.status(200).send());

app.use(history({ index: '/index.html' }));

app.use('/', express.static('dist', { index: 'index.html' }));

app.use('/api/images', express.static('images'));


app.listen(8081, () => console.log('Server listening on port 8081!'));

