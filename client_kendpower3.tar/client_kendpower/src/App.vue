<script setup>
import { RouterView } from 'vue-router'
</script>
<template>
  <Suspense>
    <RouterView />
  </Suspense>
</template>
