import { request } from "@/utils/service"

const sessionTimeout = 500;
export function loginApi(user) {
  const data = {
    jsonrpc: "2.0",
    id: 1,
    method: "call",
    params: [ 
      "00000000000000000000000000000000", 
      "session",
      "login", 
      { user, timeout: sessionTimeout.toString() }
    ]
  };
  return request({
    url: "ubus",
    method: "post",
    data 
  });
}


export function hmiInfoApi(data) {
  
  const defaultData = {
    jsonrpc: "2.0",
    id: 1,
    method: "call",
    params: [ 
      data.token,
      data.object,
      data.method,
      data.payload
    ]
  };
  /*return request({
    url: "ubus",
    method: "post",
    data : defaultData
  });*/
  //requery every 3 seconds
  const afterThreeSeconds = new Promise((resolve,reject) => {
    setTimeout(() => {
      console.log(defaultData);
      request({
        url: "ubus",
        method: "post",
        data : defaultData
      }).then(resolve,reject);
    },3000);  
    });
  return afterThreeSeconds;
}
