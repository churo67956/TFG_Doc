<script setup>
defineProps({
 "busy": { required: true, type: Boolean},
 "msg": { type: String, default: "Loading...."}
});
</script>

<template>
    <div v-if="busy" class="text-xl flex flex-col grow justify-center items-center mx-2">
        <p class="animate-bounce">{{ msg }}</p>
    </div>
</template>