<template>
    <div class="text-xl flex flex-col grow justify-center items-center mx-2">
      <h1 class="text-4xl text-red-600"> {{ $t('pageNotFound.title' ) }}</h1>
      <p><span>{{ $t('pageNotFound.ouch' ) }}</span> {{ $t('pageNotFound.description' ) }}</p>
      <p>{{ $t('pageNotFound.details' ) }}</p>
      <a href="/" class="btn btn-primary">{{ $t('pageNotFound.resolve' ) }}</a>
    </div>
  </template>
  
  <script setup>
  </script>
  