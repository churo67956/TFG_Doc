<script setup>
</script>

<template>
  <footer>
    <div class="p-5 bg-cyan-400 text-white">
      <p><i class="fa-regular fa-copyright"></i> Ingeteam</p>
    </div>
  </footer>
</template>

<style scoped>
</style>