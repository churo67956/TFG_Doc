<template>
    <Line 
      id="my-chart-id"
      :options="config"
      :data="data"
    />
  </template>


<script setup>

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import { Line } from 'vue-chartjs'
import { useI18n } from 'vue-i18n';
const { t } = useI18n();
import { Months, Numbers, CHART_COLORS} from '@/utils';


ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const labels = [0,0.3,0.5,1,1.3,2,2.5,3,3.5];
const data = {
  labels: labels,
  datasets: [
    {
      label: t('unit.power'),
      data: [0, 300,350,300,350,300,350,300,350,300,350,300,350],
      borderColor: CHART_COLORS.red,
      backgroundColor: CHART_COLORS.red,
      yAxisID: 'y',
    },
    {
      label: t('ev.batteryLevel'),
      data: [20,40,50,60,70,80,90,100,100,100,100,100],
      borderColor: CHART_COLORS.blue,
      backgroundColor: CHART_COLORS.blue,
      yAxisID: 'y1',
    }
  ]
};

const config = {
    responsive: true,
    aspectRatio: 1,
    interaction: {
      mode: 'index',
      intersect: false,
    },
    stacked: false,
    plugins: {
      title: {
        display: true,
        text: ""
      }
    },
    scales: {
      y: {
        type: 'linear',
        display: true,
        position: 'left',
      },
      y1: {
        type: 'linear',
        display: true,
        position: 'right',
        grid: {
          drawOnChartArea: false, // only want the grid lines for one axis to show up
        },
      }
    }
}


</script>