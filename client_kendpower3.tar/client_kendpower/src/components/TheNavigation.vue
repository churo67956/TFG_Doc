<script setup>
//import { useI18n } from 'vue-i18n';
//const { t, locale } = useI18n();
import TheLanguagePicker from '@/components/TheLanguagePicker.vue';
</script>

<template>
  <header class="flex flex-col md:flex-row py-1 py-2 text-gray-800 grow">
    <div id="siteName" class="text-2xl font-bold text-amber-200 p-2 whitespace-nowrap block">
      <a href="/">Kenpower</a>
    </div>
    <section>
      <!-- <RouterLink :to="`/${locale}/`">{{ t('routes.home') }}</RouterLink>
      <RouterLink :to="`/${locale}/track`">{{ t('routes.track') }}</RouterLink> -->
      <TheLanguagePicker />
    </section>
  </header>
</template>

<style scoped>
</style>
