
const whiteListByName = ["LoginPage","ErrorPage"];

const isWhiteList = (to) => {
  return whiteListByName.indexOf(to.name) !== -1;
}

export default isWhiteList;
