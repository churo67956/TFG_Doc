import i18n, {
    SUPPORTED_LOCALES,
    getDefaultLocale,
    loadLocaleMessages
  } from '@/i18n';
export function useLocale (to,from,next) {
    console.log(to, from, next);
    const paramLocale = to.params.locale;

    if (!SUPPORTED_LOCALES.includes(paramLocale)) {
    return next(getDefaultLocale());
    }

    loadLocaleMessages(i18n.global, paramLocale).then(() => {
        if (i18n.global.locale.value !== paramLocale) {
            i18n.global.locale.value = paramLocale;
            document.querySelector('html').setAttribute('lang', paramLocale);
        }
        next();
    });
}