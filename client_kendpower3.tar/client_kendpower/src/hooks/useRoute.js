import i18n from '@/i18n';

export function getLocaleRoute (name){
    return `/${i18n.global.locale.value}/${name}`;
}
