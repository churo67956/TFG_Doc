
<script setup>
import { computed } from 'vue'
import { gradientBgPurplePink, gradientBgPinkRed } from '@/colors.js'

const props = defineProps({
  bg: {
    type: String,
    required: true,
    validator: (value) => ['purplePink', 'pinkRed'].includes(value)
  }
});

const colorClass = computed(() => {
  switch (props.bg) {
    case 'purplePink':
      return gradientBgPurplePink
    case 'pinkRed':
      return gradientBgPinkRed
  }

  return ''
});
</script>

<!-- Full Scren layout -->

<template>
    <div class="flex flex-col h-dvh text-center justify-center items-center drop-shadow-2xl uppercase" :class="colorClass">
      <slot card-class="w-11/12 md:w-7/12 lg:w-6/12 xl:w-4/12 shadow-2xl" />
    </div>
</template>
