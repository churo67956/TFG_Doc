import { createApp } from 'vue'
import store from "@/stores"
import App from '@/App.vue';
import router from '@/router';
import "@/router/permissions";
import i18n from '@/i18n';

import '@/app.css';
// Create Vue app
const app = createApp(App);
app.use(store).use(router).use(i18n);
router.isReady().then(() => {
    app.mount('#app');
});