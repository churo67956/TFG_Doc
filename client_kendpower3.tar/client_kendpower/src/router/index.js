import { createRouter, createWebHistory, RouterView } from 'vue-router';
import HmiPage from '@/views/HmiPage.vue';
import ErrorPage from '@/views/ErrorPage.vue';
import LoginPage from '@/views/LoginPage.vue';
import TrackPage from '@/views/TrackPage.vue';
import i18n, {
  SUPPORTED_LOCALES,
  getDefaultLocale,
  loadLocaleMessages
} from '@/i18n';
const routes = [
  {
    path: '/:locale?',
    component: RouterView,
    /*beforeEnter(to, from, next) {
      console.log("/:locale?");
      console.log(to, from, next);
      const paramLocale = to.params.locale;
      if (!SUPPORTED_LOCALES.includes(paramLocale)) {
        return next(getDefaultLocale());
      }
      loadLocaleMessages(i18n.global, paramLocale).then(() => {
        if (i18n.global.locale.value !== paramLocale) {
          i18n.global.locale.value = paramLocale;
          document.querySelector('html').setAttribute('lang', paramLocale);
        }
        return next();
      });
    },*/
    children: [
      {
        path: '',
        name: 'HmiPage',
        component: HmiPage,
        meta: {
          title: "Charging",
        }
      },
      {
        path: 'track',
        name: 'TrackPage',
        component: TrackPage,
        meta: {
          title: "Power",
        }
      },
      {
        path:"home",
        redirect : { name: 'HmiPage' },
        meta: {
          title: "Charging",
        }
      },
      {
        meta: {
          title: 'Login'
        },
        path: 'login',
        name: 'LoginPage',
        component : LoginPage
      },
      {
        name: "ErrorPage",
        meta: {
          title: "Error",
        },
        path:':pathMatch(.*)*',
        component:ErrorPage
      },
    ]
  }
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
});

export function resetRouter() {

}
export default router;
