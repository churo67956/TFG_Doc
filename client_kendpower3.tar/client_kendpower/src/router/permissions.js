import router from "@/router";
import { useUserStoreHook } from "@/stores/modules/userStore";
import { setRouteChange } from "@/hooks/useRouteListener";
import { useTitle } from "@/hooks/useTitle";
import isWhiteList  from "@/config/whiteList";
import "nprogress/nprogress.css";
import NProgress from "nprogress"
import i18n, { SUPPORTED_LOCALES, getDefaultLocale, loadLocaleMessages }  from '@/i18n';
import { useLocale  } from "@/hooks/useLocale";
  

const { setTitle } = useTitle();
NProgress.configure({ showSpinner: false });

router.beforeEach(async (to, _from, next) => {
  console.log("router.beforeEach");
  console.log(to, _from);
  NProgress.start();
  const paramLocale = to.params.locale;
  if (!SUPPORTED_LOCALES.includes(paramLocale)) {
    return next({ path:`/${getDefaultLocale()}${to.path}`});
  }
  const userStore = useUserStoreHook();
  const token = userStore.token;
  if (!token) {
    if (isWhiteList(to)) {
        next();
    }
    else{
      NProgress.done();
      next({ path : `/${i18n.global.locale.value}/login`});
    }
    return;
  }
  console.log("authorized");
  if (to.path === "login") {
    return next({path:""});
  }
  return next();
});

router.afterEach((to) => {
  setRouteChange(to);
  setTitle(to.meta.title);
  NProgress.done();
})
