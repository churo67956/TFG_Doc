import { defineStore, acceptHMRUpdate } from 'pinia';
import store from "@/stores";
import { useUbusSessionStore } from '@/stores/modules/ubusSessionStore';
import { ref, computed } from 'vue';
import axios from 'axios';
const sides=["left","right"];

export const useHmiStore = defineStore('hmi', () => {
  let denied=false;
  const hmiStoreLoading=ref(true);
  const hmiViewStore = ref(null);
  const hmiCommonStore = ref(null);
  const ubusSession = useUbusSessionStore();
  const updateHmiStore = async () => {
    if (!ubusSession.ubusSessionLoading && hmiStoreLoading.value){
      try{
        console.log("   Querying for a HMI values");
        const response = await axios({
          method: 'POST',
          url : '/api/ubus',
          headers: {
            'Content-Type': 'application/json'
          },
          data: {
            jsonrpc: "2.0",
            id: 1,
            method: "call",
            params: [ 
              "528bb388e9cc73ebe22941509ef14027",
              "wizard",
              "etl_hmi",
              {"connector":"ccsleft"}
            ]
          }
        });
        if ( (typeof response.data == "object") ){
            if (!( "error" in response.data) &&
             "result" in response.data) { 
             if ( !response.data.result[0] ) {
                hmiViewStore.value = response.data.result[1].view;
                hmiCommonStore.value = response.data.result[1].common;
                hmiStoreLoading.value = false;
                console.log("   HMi request resolved.")
             }
             else if (response.data.result[0] == 6){
                denied = true;
             }
            }
            else{
              hmiStoreLoading.value = true;
            }    
        }
        else{
          hmiStoreLoading.value = true;
        }   
      }
      catch{
        hmiStoreLoading.value = true;
      }
      finally{
        console.log("   A new Hmi Request after 3000 seconds");
      }
    }
    else{
      console.log("   Hmi needs right to request");
    }
    setTimeout(() => {
      hmiStoreLoading.value = true;
      updateHmiStore();
    },2000);
  };
  const connector= computed( () => {
    const matches = sides.filter((side) => hmiViewStore.value.logical_connector.indexOf(side) > 0);
    if (matches && matches.length == 1){
      const side = matches[0];
      const name = hmiViewStore.value.logical_connector.substring(0,hmiViewStore.value.logical_connector.indexOf(side));
      return { side, name }
    }
    else {
      return undefined;
    }
  });
  return { denied,hmiViewStore, hmiCommonStore, updateHmiStore, connector, hmiStoreLoading };
});

export function useHmiStoreHook() {
   return useHmiStore(store);
}

if (import.meta.hot){
 import.meta.hot.accept(acceptHMRUpdate(useHmiStore, import.meta.hot));
}
