import { defineStore, acceptHMRUpdate } from 'pinia';
import store from "@/stores";
import { ref } from 'vue';
import axios from 'axios';
import { useHmiStore } from '@/stores/modules/hmiStore';

export const useUbusSessionStore = defineStore('ubusSessionStore', () => {
  console.log("defineStore ubussession");
  const ubusSessionLoading=ref(true);
  const sessionTimeout = 5; //1 minuto
  const ubusSession = ref(null);
  const hmiStore = useHmiStore();
  
  const newUbusSession = async () => {
    try{
      console.log(ubusSessionLoading.value);
      if (ubusSessionLoading.value || hmiStore.denied) {
        hmiStore.denied = false;
        ubusSessionLoading.value = true;
        console.log("Querying for a new session key");
        const response = await axios({
          method: 'POST',
          url : '/api/ubus',
          headers: {
            'Content-Type': 'application/json'
          },
          data: {
            jsonrpc: "2.0",
            id: 1,
            method: "call",
            params: [ 
              "00000000000000000000000000000000", 
              "session",
              "login", 
              { username: "mobile",password: "changeme",timeout: String.toString(sessionTimeout)}
            ]
          }
        });
        if (( typeof response.data == "object" ) &&
              !( "error" in response.data) &&
              "result" in response.data && 
              !response.data.result[0] ) {
          ubusSession.value=response.data.result[1];
          console.log("Session request resolved. The new session key is " + response.data.result[1].ubus_rpc_session);
          ubusSessionLoading.value = false;
          console.log(ubusSessionLoading.value);
          sessionTimeoutMonitor();
        }
        else{//an error
          ubusSessionLoading.value = true;
        }  
      }
      else{
        console.log("No need to request a new session is still running");
      } 
    }
    //catch { //retry after 3s
    //  ubusSessionLoading.value = true;
    //}
    finally{
      console.log("A new Session Request after 3000 seconds");
      setTimeout(newUbusSession,10000);
    }
  }
  const sessionTimeoutMonitor = () => {
    
    setTimeout( () => {
      console.log("Session is up. Need to restat.")
      ubusSession.value = null;
      ubusSessionLoading.value = true;
      console.log(ubusSessionLoading.value);
    },sessionTimeout*1000);
  }
  return { ubusSessionLoading, ubusSession, newUbusSession };
});

export function newUbusSession() {
  return newUbusSession(store);
}

if (import.meta.hot){
 import.meta.hot.accept(acceptHMRUpdate(useUbusSessionStore, import.meta.hot));
}
