import { ref, computed } from "vue";
import store from "@/stores";
import { defineStore } from "pinia";
import { hmiInfoApi } from "@/api";
const sides=["left","right"];
export const useHmiStore = defineStore("hmi", () => {
  const hmiConnectorStore = ref({});
  const hmiCommonStore = ref({});
  const getHmiInfo =  (token) => {
    return hmiInfoApi( { token ,
      object: "wizard",
      method : "etl_hmi",
      payload: {"connector": hmiConnectorStore.value.logical_connector}})
    .then(hmiInfoUpdate);
  };
  const hmiInfoUpdate = (data) => {
    hmiConnectorStore.value = {whoLimits : "evseLimits", ...data.view};
    console.log(hmiConnectorStore.value);
    hmiCommonStore.value = data.common;
    return data;
  }
  const connector= computed( () => {
    const matches = sides.filter((side) => hmiConnectorStore.value.logical_connector.indexOf(side) > 0);
    if (matches && matches.length == 1){
      const side = matches[0];
      const name = hmiConnectorStore.value.logical_connector.substring(0,hmiConnectorStore.value.logical_connector.indexOf(side));
      return { side, name }
    }
    else {
      return undefined;
    }
  });
  return {  hmiConnectorStore, hmiCommonStore, connector,getHmiInfo };
});

export function useHmiStoreHook() {
  return useHmiStore(store)
};
