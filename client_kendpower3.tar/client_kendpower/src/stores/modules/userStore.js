import { ref } from "vue"
import store from "@/stores"
import { defineStore } from "pinia"
import { loginApi } from "@/api"

export const useUserStore = defineStore("user", () => {
  const token = ref("");
  const username = ref("");
  const role = ref("")
  const login =  (user) => {
      return loginApi(user).
      then((data) => token.value = data.ubus_rpc_session );
  };
  const logout = () => {
    token.value = ""
  };
  const resetToken = () => {
    token.value = ""
  };
  return { role, token, username, login, logout, resetToken };
});

export function useUserStoreHook() {
  return useUserStore(store)
};
