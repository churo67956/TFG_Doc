import axios from "axios"
import { useUserStoreHook } from "@/stores/modules/userStore"
import { ElMessage } from "element-plus"
import { get, merge } from "lodash-es"
import i18n from '@/i18n';
const { t } = i18n.global;
function logout() {
  useUserStoreHook().logout()
  location.reload()
}

const doLater = (callback,time) =>  {
  return new Promise((resolve) => {
    setTimeout(() => {
      callback();
      resolve()
    }, time);
  });
}

function createService() {
  const service = axios.create();
  service.interceptors.request.use(
    (config) => config,
    (error) => Promise.reject(error)
  )
  service.interceptors.response.use(
    (response) => {
      const apiData = response.data;
      const responseType = response.request?.responseType;
      if (responseType === "blob" || responseType === "arraybuffer") return apiData;

      const code = ( "result" in apiData ) ? apiData.result[0] : ( "error" in apiData ) ? apiData.error.code : undefined;
      if (code === undefined) {
        ElMessage.error($t('request.error.code'));
        return Promise.reject({ code });
      }
      if  (!code && apiData.result[1] && typeof apiData.result[1] === "object") {
          return apiData.result[1];
      }
      const errorMessage =  ( "error" in apiData ) ? apiData.error.message : t('request.error.default');
      ElMessage.error(errorMessage);
      console.log(errorMessage);
       return Promise.reject({code});
      
    },
    (error) => {
      const code = get(error, "response.status");
      ElMessage.error(t('request.error.default') + ":" + code.toString());
      return Promise.reject({})
    }
  )
  return service;
}

function createRequest(service) {
  return (config) => {
    const defaultConfig = {
      headers: {
        "Content-Type": "application/json"
      },
      timeout: 5000,
      baseURL: import.meta.env.VITE_BASE_API,
      data: {}
    };
    const mergeConfig = merge(defaultConfig, config)
    return service(mergeConfig)
  }
}

const service = createService()
export const request = createRequest(service)
