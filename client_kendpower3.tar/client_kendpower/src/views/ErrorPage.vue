<script setup>
import { useI18n } from 'vue-i18n';
import CardBox from '@/components/Generic/CardBox.vue';
import BaseButton from '@/components/Generic/BaseButton.vue';
import BaseButtons from '@/components/Generic/BaseButtons.vue';
import MainLayout from '@/layout/MainLayout.vue';
const { t } = useI18n();
</script>

<template>
  <MainLayout v-slot="{ cardClass }" bg="pinkRed">
      <CardBox :class="cardClass" :isModal="true" :isHoverable="true">
        <div class="space-y-3">
          <h1 class="text-2xl"> {{$t('exception.unknown.title')}}</h1>
          <p>{{$t('exception.unknown.detail')}}</p>
        </div>  
        <template #footer>
          <BaseButtons>
            <BaseButton :label="t('exception.unknown.handle')" to="home" color="danger" />
          </BaseButtons>
        </template>
      </CardBox>
  </MainLayout>
</template>
