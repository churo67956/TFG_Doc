
<script setup>
import {ref, onMounted, computed } from 'vue';
import { useI18n } from 'vue-i18n';
import { storeToRefs } from 'pinia';
import { useHmiStore } from '@/stores/modules/useHmiStore';
import { useUserStore } from "@/stores/modules/userStore"
import LoadingData from '@/components/Generic/LoadingData.vue';
import { RouterLink } from 'vue-router';
import MainLayout from '@/layout/MainLayout.vue'
import { useRouter } from "vue-router"
import { getLocaleRoute } from "@/hooks/useRoute"
const { t, n, locale } = useI18n();
const router = useRouter()
const userStore = useUserStore();
const hmiStore = useHmiStore();
let {  hmiConnectorStore, connector } = storeToRefs(hmiStore);
const { getHmiInfo } = hmiStore;
const loading = ref(true);
const displayLimit = ref(false);

function displayLimitToggle ()  {
  displayLimit.value = !displayLimit.value;
}
  
hmiStore.$onAction(({ name, store, args, after, onError}) =>{ 
  onError((error)=>{
    if (name == "getHmiInfo")
      if (error.code){
        console.log("Hmi Request Error");
        router.push({ path : getLocaleRoute("login")});
      } 
  });
  after((result) => {
    if (name == "getHmiInfo")
      getHmiInfo(userStore.token);      
  });
});

const batteryLevel = ref(5);

getHmiInfo(userStore.token)
.then(() => loading.value = false)
.catch((error) => console.log(error));

</script>

<template>
<MainLayout v-slot="{ cardClass }" >
   <LoadingData :busy="loading" :class="cardClass" :msg="t('loadingData.fetch')" />
   
   <!-- {{hmiStore.loading }} -->
   <div id="main" v-if="!loading" class="flex flex-col grow" :class="cardClass">
        <div v-if="connector" id="connector" class="text-2xl text-white flex flex-row gap-2 bg-cyan-400 p-5 justify-center">
          <div  id="connectorName">
            <span>{{ connector.name }}</span>
          </div>
          <div id="connectorSide">
            <span>{{ t( 'connector.side.' + connector.side) }}</span> 
          </div>
        </div>
        <div v-if="!connector"  class="text-2xl text-white bg-cyan-400 p-5">
          <span class="text-4xl ">{{ hmiConnectorStore.logical_connector }}</span>
        </div>
        <div id="connectorState">
          <p class="text-4xl p-5 text-cyan-400">{{  t( 'connector.fsm.' + hmiConnectorStore.fsm_state) }}</p>
        </div>

        <div v-if ="!displayLimit"  class="flex flex-row gap-2 p-5">
          <div  id="connectorPower" class="flex-auto text-right">
            <span class="text-2xl lowercase">{{ hmiConnectorStore.power }} kW</span>
          </div>
          <div id="powerLimit" class="animate-bounce flex-auto text-right text-red-500" @click="displayLimitToggle">
            <span >{{ t('hmi.' + hmiConnectorStore.whoLimits) }}</span> 
          </div>
        </div>
        <div v-if="displayLimit" @click="displayLimitToggle" class="bg-red-500 text-white p-3">
          <div>
            <p class="text-1xl"> Max. {{ t('track.chargingPower') }} </p>
          </div>
          <div  class="flex flex-row gap-2">
            <div class="flex-auto text-right">
              <span class="text-ms">  {{n( parseFloat(hmiConnectorStore.power),"decimal")}}  kW</span>
            </div>
            <div class="flex-auto text-left">
              <span class="text-ms">  {{n( parseFloat(hmiConnectorStore.voltage),"decimal")}} V</span>
            </div>
          </div>
        </div>
        <RouterLink :to="`/${locale}/track`" custom v-slot="{navigate}">
          <div id="statusBar" class="flex flex-wrap justify-center grow pt-5 pb-5 mx-12"  @click="navigate">
            <div class="flex flex-col p-1">
              <div class="flex-auto">
                <p class="lowercase">2 h</p>
              </div>
              <div class="flex flex-col flex-auto justify-end">
                <div class="flex flex-col flex-auto justify-start lowercase">1 h</div>
                <p class="text-center lowercase">0 h</p>
              </div>
            </div>
            <div class="flex flex-col grow justify-end items-center rounded border-2 border-gray-400">
                 
                <div v-for="level in 5" :class="[level == 1 ? `animate-pulse bg-green-500` : '',level == 2 ? `bg-green-400` : '' ,level == 3 ? `bg-yellow-400` : '',level == 4 ? `bg-yellow-300` : '',level == 5 ? `bg-red-400` : '',`h-1/6 w-full`]" > {{ n((5 - level + 1) * 16.6666 , 'decimal', { minimumFractionDigits: 0 }) }}</div>
                <!--<div class="h-1/6 bg-green-500 w-full">83.3%</div> 4 - 1 + 1 - 4
                <div class="h-1/6 bg-green-400 w-full">66.6%</div> 4 -2 +1  - 3
                <div class="h-1/6 bg-green-300 w-full">50%</div>   4 -3 + 1 - 2
                <div class="h-1/6 bg-green-200 w-full">33.3%</div>
                <div class="h-1/6 bg-green-100 w-full">16.6%</div> -->
            </div>      
            <div class="flex flex-col p-1">
              <div class="flex-auto">
               <p class="">100 %</p>
              </div>
              <div class="flex flex-col flex-auto justify-end">
                  <div class="flex flex-col flex-auto justify-start">50 %</div>
                  <p class="text-center">0 %</p>
              </div>
            </div>                
    
          </div>
        </RouterLink>
        <div id="connectorSoc">
          <p class="text-6xl p-5">{{ hmiConnectorStore.soc }} %</p>
        </div>
        <div id="connectorEnergy ">
          <p class="text-xl text-cyan-400 p-1 lowercase"> +{{ hmiConnectorStore.energy }} kWH </p>
        </div>
    </div>
</MainLayout>
</template>

<style scoped>
</style>