<script setup>
import { watch,computed } from 'vue'
import { storeToRefs } from "pinia";
import CardBox from '@/components/Generic/CardBox.vue'
import FormCheckRadio from '@/components/Generic/FormCheckRadio.vue'
import FormField from '@/components/Generic/FormField.vue'
import FormControl from '@/components/Generic/FormControl.vue'
import BaseButton from '@/components/Generic/BaseButton.vue'
import BaseButtons from '@/components/Generic/BaseButtons.vue'
import MainLayout from '@/layout/MainLayout.vue'
import { useRouter } from "vue-router"
import { useUserStore } from "@/stores/modules/userStore"
import { useHmiStore } from  "@/stores/modules/useHmiStore"
import { getLocaleRoute } from "@/hooks/useRoute"

const router = useRouter()
const userStore = useUserStore();
const hmiStore = useHmiStore();
const { token } = storeToRefs(userStore);  

console.log(router.currentRoute.value.query);

const form = computed( () => {
  return {
    login :  userStore.username || 'movile',
    pass:   userStore.role == "guest" ? 'changeme' : "",
    remember: true
  }
});


const submit = () => {
  console.log("Login Request");
  userStore
    .login({username : form.value.login,password: form.value.pass  })
    .then(() => router.push({ path : getLocaleRoute("home")})) 
    .catch((error) => console.log(error));
}

userStore.$onAction(({ name, store, args, after, onError}) =>{ 
  onError((error)=>{
    if (name == "login")
      console.log("Login Request error");
      if (error.code){
        userStore.login({username : form.value.login,password: form.value.pass  });
      } 
  });
});

hmiStore.hmiConnectorStore.logical_connector =  router.currentRoute.value.query.lc || hmiStore.hmiConnectorStore.logical_connector ;
  
//get logicalconnector
if ( !hmiStore.hmiConnectorStore.logical_connector ){
  console.log("No logical connector");
  router.push({path : getLocaleRoute("error")});
}
else{
  //get rol
  userStore.role = router.currentRoute.value.query.role || userStore.role ;
  if ( userStore.role ==  "guest"){
    console.log("A guest ")
    submit();
  }
  else{
    form.value.login = "";
    form.value.pass= "";
  }
}

</script>

<template>
  <MainLayout v-slot="{ cardClass }" bg="purplePink">
      <CardBox :class="cardClass" is-form @submit.prevent="submit">
        <FormField label="Login" help="Please enter your login">
          <FormControl
            v-model="form.login"
            name="login"
            autocomplete="username"
          />
        </FormField>

        <FormField label="Password" help="Please enter your password">
          <FormControl
            v-model="form.pass"
            type="password"
            name="password"
            autocomplete="current-password"
          />
        </FormField>

        <FormCheckRadio
          v-model="form.remember"
          name="remember"
          label="Remember"
          :input-value="true"
        />

        <template #footer>
          <BaseButtons>
            <BaseButton type="submit" color="info" label="Login" />
          </BaseButtons>
        </template>
      </CardBox>
  </MainLayout>
</template>
