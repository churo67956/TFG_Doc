
<script setup>
import {ref,onMounted} from 'vue'
import { useI18n } from 'vue-i18n';
import { storeToRefs } from 'pinia';
import { useHmiStore } from '@/stores/modules/useHmiStore';
import { RouterLink } from 'vue-router';
import LoadingData from '@/components/Generic/LoadingData.vue';
import MultiLineChart from '@/components/TheMultiLineChart.vue';
import MainLayout from '@/layout/MainLayout.vue'
const { t, n, locale } = useI18n();
const hmiStore = useHmiStore();
let { hmiConnectorStore } = storeToRefs(hmiStore);
const { updateHmiStore } = hmiStore;
const isBusy=ref(true);

/*onMounted( async ()=> {
  isBusy.value = true
  try{
    updateHmiStore();
  } catch{
    console.log("error");
  } finally {
    setTimeout( () => isBusy.value = false, 1000);
  }
});*/
</script>

<template>
  <MainLayout v-slot="{ cardClass }" >
  <!--<LoadingData :busy="isBusy" :msg="t('loadingData.fetch')" />-->
  <div id="main" :class="cardClass" class="flex flex-col grow">
    <div class="text-2xl text-white flex flex-row gap-2 bg-cyan-400 p-5">
      <div class="flex-auto text-right">
        <span>{{  hmiConnectorStore.fsm_state }}</span>
      </div>
      <div id="connectorSide" class="flex-auto text-right">
        <RouterLink :to="`/${locale}/`" custom v-slot="{navigate}">
          <div @click="navigate">
            <i class="fa-solid fa-xmark"></i>
          </div> 
        </RouterLink>
      </div>
    </div>
    <div class="flex flex-col grow justify-center items-center p-3">
      <MultiLineChart></MultiLineChart>
    </div>
    <div>
      <p class="text-2xl">{{ t('track.chargingPower') }} </p>
    </div>
    <div class="flex flex-row gap-2 p-5">
      <div class="flex-auto text-left">
        <span class="text-ms"> {{ t('unit.power') + ": " + n( parseFloat(hmiConnectorStore.power),"decimal")}}  kW</span>
      </div>
      <div class="flex-auto text-right">
        <span class="text-ms"> {{ t('unit.voltage') + ": " + n( parseFloat(hmiConnectorStore.voltage),"decimal")}} V</span>
        </div>
    </div>
    <div class="flex flex-row gap-2 p-5"> 
    <div class="flex-auto text-left">
      <span class="text-ms"> Max: {{  n( parseFloat(hmiConnectorStore.power),"decimal")}} kW</span>
    </div>
    <div class="flex-auto text-right">
      <span class="text-ms"> {{ t('unit.current') + ": " + n( parseFloat(hmiConnectorStore.current),"decimal")}} A</span> 
    </div>
    </div>
 </div>
 </MainLayout>
</template>

<style scoped>
</style>