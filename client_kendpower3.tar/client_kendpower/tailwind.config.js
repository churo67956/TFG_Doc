/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./src/**/*.{js,html,vue}",
    "./public/**/*.html",
    "./index.html"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

