// vite.config.js
import { fileURLToPath, URL } from "node:url";
import { defineConfig } from "file:///mnt/c/Users/erikc/Documents/Projects/FrontEnd/vite/client_kendpower/client_kendpower/node_modules/vite/dist/node/index.js";
import vue from "file:///mnt/c/Users/erikc/Documents/Projects/FrontEnd/vite/client_kendpower/client_kendpower/node_modules/@vitejs/plugin-vue/dist/index.mjs";
import VueI18nPlugin from "file:///mnt/c/Users/erikc/Documents/Projects/FrontEnd/vite/client_kendpower/client_kendpower/node_modules/@intlify/unplugin-vue-i18n/lib/vite.mjs";
var __vite_injected_original_import_meta_url = "file:///mnt/c/Users/erikc/Documents/Projects/FrontEnd/vite/client_kendpower/client_kendpower/vite.config.js";
var vite_config_default = defineConfig({
  plugins: [vue(), VueI18nPlugin()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", __vite_injected_original_import_meta_url))
    }
  },
  server: {
    proxy: {
      /* '/ubus': {
         target: 'http://172.19.1.37:8080',
       },*/
      "/api": {
        target: "http://localhost:8081"
      }
    },
    watch: {
      usePolling: true
    }
  }
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCIvbW50L2MvVXNlcnMvZXJpa2MvRG9jdW1lbnRzL1Byb2plY3RzL0Zyb250RW5kL3ZpdGUvY2xpZW50X2tlbmRwb3dlci9jbGllbnRfa2VuZHBvd2VyXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ZpbGVuYW1lID0gXCIvbW50L2MvVXNlcnMvZXJpa2MvRG9jdW1lbnRzL1Byb2plY3RzL0Zyb250RW5kL3ZpdGUvY2xpZW50X2tlbmRwb3dlci9jbGllbnRfa2VuZHBvd2VyL3ZpdGUuY29uZmlnLmpzXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ltcG9ydF9tZXRhX3VybCA9IFwiZmlsZTovLy9tbnQvYy9Vc2Vycy9lcmlrYy9Eb2N1bWVudHMvUHJvamVjdHMvRnJvbnRFbmQvdml0ZS9jbGllbnRfa2VuZHBvd2VyL2NsaWVudF9rZW5kcG93ZXIvdml0ZS5jb25maWcuanNcIjtpbXBvcnQgeyBmaWxlVVJMVG9QYXRoLCBVUkwgfSBmcm9tICdub2RlOnVybCc7XG5pbXBvcnQgeyBkZWZpbmVDb25maWcgfSBmcm9tICd2aXRlJ1xuaW1wb3J0IHZ1ZSBmcm9tICdAdml0ZWpzL3BsdWdpbi12dWUnXG5pbXBvcnQgVnVlSTE4blBsdWdpbiBmcm9tICdAaW50bGlmeS91bnBsdWdpbi12dWUtaTE4bi92aXRlJztcblxuLy8gaHR0cHM6Ly92aXRlanMuZGV2L2NvbmZpZy9cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIHBsdWdpbnM6IFt2dWUoKSwgVnVlSTE4blBsdWdpbigpXSxcbiAgcmVzb2x2ZToge1xuICAgIGFsaWFzOiB7XG4gICAgICAnQCc6IGZpbGVVUkxUb1BhdGgobmV3IFVSTCgnLi9zcmMnLCBpbXBvcnQubWV0YS51cmwpKVxuICAgIH1cbiAgfSxcbiAgc2VydmVyOiB7XG4gICAgcHJveHk6IHtcbiAgICAgLyogJy91YnVzJzoge1xuICAgICAgICB0YXJnZXQ6ICdodHRwOi8vMTcyLjE5LjEuMzc6ODA4MCcsXG4gICAgICB9LCovXG4gICAgICAnL2FwaSc6ICB7XG4gICAgICAgIHRhcmdldDogJ2h0dHA6Ly9sb2NhbGhvc3Q6ODA4MScsXG4gICAgICB9XG4gICAgfSxcbiAgICB3YXRjaDoge1xuICAgICAgdXNlUG9sbGluZzogdHJ1ZVxuICAgIH1cbiAgfVxufSlcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBaWIsU0FBUyxlQUFlLFdBQVc7QUFDcGQsU0FBUyxvQkFBb0I7QUFDN0IsT0FBTyxTQUFTO0FBQ2hCLE9BQU8sbUJBQW1CO0FBSHdQLElBQU0sMkNBQTJDO0FBTW5VLElBQU8sc0JBQVEsYUFBYTtBQUFBLEVBQzFCLFNBQVMsQ0FBQyxJQUFJLEdBQUcsY0FBYyxDQUFDO0FBQUEsRUFDaEMsU0FBUztBQUFBLElBQ1AsT0FBTztBQUFBLE1BQ0wsS0FBSyxjQUFjLElBQUksSUFBSSxTQUFTLHdDQUFlLENBQUM7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFFBQVE7QUFBQSxJQUNOLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlMLFFBQVM7QUFBQSxRQUNQLFFBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTztBQUFBLE1BQ0wsWUFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBQ0YsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
