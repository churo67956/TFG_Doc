<script setup>
import TheNavigation from '@/components/TheNavigation.vue';

</script>

<template>
  <TheNavigation />
  <div>
    <RouterView />
  </div>
</template>

<style scoped>
</style>
