<template>
    <div class="d-flex align-items-center justify-content-center vh-100">
              <div class="text-center">
                  <h1 class="display-1 fw-bold"> {{ $t('pageNotFound.title' ) }}</h1>
                  <p class="fs-3"> <span class="text-danger">{{ $t('pageNotFound.ouch' ) }}</span> {{ $t('pageNotFound.description' ) }}</p>
                  <p class="lead">
                    {{ $t('pageNotFound.details' ) }}
                    </p>
                  <a href="/" class="btn btn-primary">{{ $t('pageNotFound.resolve' ) }}</a>
              </div>
          </div>
  </template>
  
  <script setup>
  </script>
  