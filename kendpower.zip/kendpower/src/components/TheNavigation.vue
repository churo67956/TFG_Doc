<script setup>
import { useI18n } from 'vue-i18n';
import TheLanguagePicker from '@/components/TheLanguagePicker.vue';

const { t, locale } = useI18n();
</script>

<template>
  <div class="nav">
    <div>
      <span class="logo">Kendpower</span>
      <RouterLink :to="`/${locale}/`">{{ t('routes.home') }}</RouterLink>
      <RouterLink :to="`/${locale}/track`">{{ t('routes.track') }}</RouterLink>
      <TheLanguagePicker />
    </div>
  </div>
</template>

<style scoped>
</style>
