import { createRouter, createWebHistory, RouterView } from 'vue-router';
import HomePage from '@/views/HomePage.vue';
import TrackPage from '@/views/TrackPage.vue';
import PageNotFound from '@/components/Generic/PageNotFound.vue';
import i18n, {
  SUPPORTED_LOCALES,
  getDefaultLocale,
  loadLocaleMessages
} from '@/i18n';

const routes = [
  {
    path: '/:locale?',
    component: RouterView,
    beforeEnter(to, from, next) {
      console.log(to, from, next);
      const paramLocale = to.params.locale;

      if (!SUPPORTED_LOCALES.includes(paramLocale)) {
        return next(getDefaultLocale());
      }

      loadLocaleMessages(i18n.global, paramLocale).then(() => {
        if (i18n.global.locale.value !== paramLocale) {
          i18n.global.locale.value = paramLocale;
          document.querySelector('html').setAttribute('lang', paramLocale);
        }

        return next();
      });
    },
    children: [
      {
        path: '',
        name: 'HomePage',
        component: HomePage,
      },
      {
        path: 'track',
        name: 'TrackPage',
        component: TrackPage,
      },
      {
        path:':pathMatch(.*)*',
        component:PageNotFound
      }
    ]
  }
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
});

export default router;
