import { defineStore } from 'pinia';
import { ref } from 'vue';
import axios from 'axios';

export const useChargingSessionStore = defineStore('chargingSession', () => {
  const chargingSession = ref(null);

  const getChargingSession = async () => {
    const response = await axios({
      url : '/api/chargingSession',
      method : 'GET'
    });
    chargingSession.value = JSON.stringify(response.data);
    console.log(chargingSession.value);
  };

  return { chargingSession, getChargingSession };
});
