
<script setup>
import { useI18n } from 'vue-i18n';
const { t } = useI18n();
import { useChargingSessionStore } from '@/stores/chargingSessionStore';

const chargingSession = useChargingSessionStore();
chargingSession.getChargingSession();
</script>

<template>
  <div class="Home">
    <h1>{{ t('routes.home') }}</h1>
    <p>{{ t('home.title') }}</p>
  </div>
</template>

<style scoped>
</style>