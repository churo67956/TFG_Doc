
<script setup>
import { useI18n } from 'vue-i18n';
const { t } = useI18n();
</script>

<template>
  <div>
    <h1>{{ t('routes.track') }}</h1>
    <p>{{ t('track.title') }}</p>
  </div>
</template>

<style scoped>
</style>