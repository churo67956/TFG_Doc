/** @type {import('tailwindcss').Config} */
export default {
  prefix: "twc-",
  content: [
    "./src/**/*.{js,html,vue}",
    "./public/**/*.html",
    "./index.html"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

