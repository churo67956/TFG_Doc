const path = require('path')
const express = require("express");
const history = require('connect-history-api-fallback');

const app = express();

app.get('/api/chargingSession', (req, res) =>
  res.send({
        id: 1,
        description:
          "A robot head with an unusually large eye and teloscpic neck -- excellent for exploring high spaces.",
        title: "Large Cyclops",
        imageUrl: "/api/images/head-big-eye.png",
        type: "heads",
        cost: 1225.5
  })
);

app.post('/api/cart', (req, res) =>
  setTimeout(() => res.status(201).send(), 800)
);

app.post('/api/sign-in', (req, res) => res.status(200).send());

app.use(history({ index: '/index.html' }));

app.use('/', express.static('dist', { index: 'index.html' }));

app.use('/api/images', express.static('images'));

app.listen(8081, () => console.log('Server listening on port 8081!'));

