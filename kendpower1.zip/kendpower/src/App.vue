<script setup>
import TheNavigation from '@/components/TheNavigation.vue';
import TheFooter from '@/components/TheFooter.vue';

</script>

<template>
  <!--<main class="flex flex-col h-dvh">
    <div class="p-5 bg-red-400">
      <p class="text-center">Connector</p>   
    </div>
    <div class="p-5 bg-yellow-400">
      <p class="text-center">Status</p>   
    </div>
    <div class="p-5 bg-cyan-400">
      <p class="text-center">Power</p>   
    </div>
    <div class="flex-grow bg-blue-400">

     </div>
    <div class="p-5 bg-red-400">
      <p class="text-center">Soc</p>   
    </div>
    <div class="p-5 bg-grey-400">
      <p class="text-center">Energy</p>   
    </div>
  </main>
  <footer class="p-5 bg-green-400">
    <p class="text-center">Footer</p>   
  </footer>-->
  <TheNavigation />
  <RouterView />
  <TheFooter />
</template>

<style scoped>
</style>
