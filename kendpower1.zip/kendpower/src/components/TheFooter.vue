<script setup>
import { useI18n } from 'vue-i18n';
import TheLanguagePicker from '@/components/TheLanguagePicker.vue';

const { t, locale } = useI18n();
</script>

<template>
  <footer class="p-2 bg-red-500">
    <p class="text-xl text-center">Footer</p>
  </footer>
</template>

<style scoped>
</style>
