<script setup>
import { useI18n } from 'vue-i18n';
import TheLanguagePicker from '@/components/TheLanguagePicker.vue';

const { t, locale } = useI18n();
</script>

<template>
  <div class="p-2 bg-cyan-500">
    <div class="flex w-full justify-between">
      <div class="text-xs">Kendpower</div>
      <div class="flex">
        <RouterLink class="mx-2 text-xs" :to="`/${locale}/`">{{ t('routes.home') }}</RouterLink>
        <RouterLink class="mx-2 text-xs" :to="`/${locale}/track`">{{ t('routes.track') }}</RouterLink>
        <TheLanguagePicker />
      </div>
    </div>
  </div>
</template>

<style scoped>
</style>
