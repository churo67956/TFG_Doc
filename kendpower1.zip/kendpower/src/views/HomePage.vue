
<script setup>
import { useI18n } from 'vue-i18n';
const { t } = useI18n();
import { useChargingSessionStore } from '@/stores/chargingSessionStore';

const chargingSession = useChargingSessionStore();
//chargingSession.getChargingSession();
</script>

<template>
  <div class="flex flex-row gap-1 p-3 bg-slate-500">
    <div class="flex-auto"><p class="text-4xl text-right">CSS</p></div>
    <div class="flex-auto"><p class="text-4xl text-left">Left</p></div>
  </div>
  <div class="p-3 bg-red-500">
    <p class="text-4xl">Status</p>
  </div>
  <div class="p-3 bg-blue-500">
    <p>Power</p>
  </div>
  <div class="flex-grow p-6 bg-green-500">
    <p>Battery level</p>
  </div>
  <div class="p-3 bg-red-500">
    <p class="text-4xl">Soc</p>
  </div>
  <div class="p-3 bg-green-500">
    <p class="text-xl">Energy</p>
  </div>
</template>

<style scoped>
</style>