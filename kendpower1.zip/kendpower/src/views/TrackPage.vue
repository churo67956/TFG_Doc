
<script setup>
import { useI18n } from 'vue-i18n';
const { t } = useI18n();
</script>

<template>
  <div class="flex grow justify-center items-center gap-4">
    <p>{{ t('routes.track') }}</p>
    <p>{{ t('routes.track') }}</p>
  </div>
</template>

<style scoped>
</style>