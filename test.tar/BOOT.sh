R_boot_init(){
  logger -t LAVA R_boot_init
}
