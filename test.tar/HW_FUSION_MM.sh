R_HW_FUSION_MM_fsm(){
 while [ $# -gt 0 ]
 do
   case "$1" in
    fsm=*)
       logger -t LAVA "R_HW_FUSION_MM_fsm fsm=${1:4}" 
     ;;
     *)
       return 1
     ;;
   esac
   shift
 done 
}

R_HW_FUSION_MM_tag(){
 while [ $# -gt 0 ]  
 do
   case "$1" in
    validation=*)
       logger -t LAVA "R_HW_FUSION_MM_tag validation=${1:11}"
     ;;
     *)
       return 1
     ;;
   esac
   shift
 done
}
R_HW_FUSION_MM_power(){
 logger -t LAVA "R_HW_FUSION_MM_power"
}
