
R_PROXMARK3_swip(){
 local tag
 local response
 logger -t "LAVA" R_PROXMARK3_swip "$*" 
 while [ $# -qt 0 ]
 do
   case "$1" in
    tag=*)
       response=$(eval REST_"$HW_VERSION"_handle method=swip "$1")
       action_accepted $response
    ;;
   esac
   shift
 done
}

