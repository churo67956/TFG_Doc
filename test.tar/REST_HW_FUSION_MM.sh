rest_get(){
 local resp
 local status
 logger -t LAVA "GET $1"
 #resp=$(wget -qO- "$1")
 #logger -t LAVA "$resp"
 #status=$(echo "$resp" | jsonfilter -e @.result )
 #if ! [ "$status" = "pass" ]; then return 1; fi
 #echo "$resp"
 return 0
}


rest_HW_FUSION_MM_hander(){
 local action="$1"
 shift
 local payload=$*
 case "$1" in
   method=swip)
     rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/rfid?$1")
   ;;
   method=relays)
     shift
     case "$1" in
      action=on)
        rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/relay/on?$1")
      ;;
      action=off)
        rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/relay/off?$1")
      ;;
     esac
   ;;       
 esac  
} 
