R_SIMULATOR_AC_start(){
 logger -t LAVA R_SIMULATOR_AC_start
 //ground connect

}
R_SIMULATOR_AC_stop(){
 logger -t LAVA R_SIMULATOR_AC_stop
}
