#delegate the action to another device
. ${TEST_SUITE_ROOT_PATH}/utils_"$HW_VERSION"/actions.sh

A_02_actualizacion_webmanager_init(){ 
 /etc/init.d/moutd stop || true
 wget -qO- $HW_JENKINS_artefacs | jsonfilter -e @.artifacts[1].relativePath | ( read line; case "$line" in  *tar.bz2*) echo $HW_JENKINS_url/$line; ;; esac ) | xargs wget -O /tmp/usbopkgs.tar.bz2 || ( echo "[ERROR]: Imposible Descargar"; return 1) 
 reiturn 0;
 }
A_02_actualizacion_webmanager_end(){ return 0; }
A_02_actualizacion_webmanager_upgrade(){
 
}


