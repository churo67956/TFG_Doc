#delegate the action to another device
. ${TEST_SUITE_ROOT_PATH}/utils_"$HW_VERSION"/actions.sh

A_01_actualizacion_opkg_init(){ return 0; }
A_01_actualizacion_opkg_end(){ return 0; }

