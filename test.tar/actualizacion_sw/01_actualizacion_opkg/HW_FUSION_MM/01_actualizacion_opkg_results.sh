#delegate the action to another device
[ -f $TEST_SUITE_ROOT_PATH/utils_"$HW_VERSION"/results.sh ]  && . $TEST_SUITE_ROOT_PATH/utils_"$HW_VERSION"/results.sh

R_01_actualizacion_opkg_upgrade(){
  local upgradable_after="$(opkg list_upgradable)"                     
  if [[ -n "$upgradable_after" ]];then
    return 1                         
  fi                                                         
}
