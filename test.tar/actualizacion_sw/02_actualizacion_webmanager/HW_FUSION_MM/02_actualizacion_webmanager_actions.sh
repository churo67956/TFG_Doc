#delegate the action to another device
. ${TEST_SUITE_ROOT_PATH}/utils_"$HW_VERSION"/actions.sh

A_02_actualizacion_webmanager_init(){ return 0; }
A_02_actualizacion_webmanager_end(){ return 0; }
A_02_actualizacion_webmanager_upgrade(){
 rest_HW_FUSION_MM_handler  method=system_upgrade
}


