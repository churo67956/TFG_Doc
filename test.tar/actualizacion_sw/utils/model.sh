#methods to manipulate json
set +x
. $TEST_SUITE_ROOT_PATH/utils_"$DUT"/js.sh
. $TEST_SUITE_ROOT_PATH/utils_"$DUT"/model.sh

model_get(){
 while [ $# -gt 0 ]
 do
   case $1 in
      key=action*)
         _js="$_step"
         _action="$(js_get action | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g")"
      ;;
      key=results*)
         _js="$_step"
         _results="$(js_get "results[*]" | tr ',' '\n' | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g")"
         _resmax=$(echo "$_results" | wc -l)
      ;;
      *)
        logger -t LAVA " key $1 not found" 
      ;; 
   esac
   shift
 done
}

model_has_connectors(){
  local str='export HW_"$HW_VERSION"_conn="'
  case "$*" in
   *"$HW_VERSION"_left*)
      str="$str"left
    ;;
  esac
  case "$*" in
   *"$HW_VERSION"_right*)
     str="$str right"
   ;;
  esac
  str=$str'"'
  echo $*$str
}

model_get_collection(){
  while [ $# -gt 0 ]
  do
      _js=$RAW_MODEL
      case "$1" in
        collection=HW_VERSION*)
          local exports=""
          exports=$(js_get "HW_VERSION[*]" | while read obj
          do
            _js="$obj"
            model_object_load
          done) || true
          exports="$(model_has_connectors "$exports")"
          [ -n "$exports" ] && eval "$exports"
        ;;
        collection=steps*)
          _steps=$(js_get "steps[*]")
          _stsmax=$(echo "$_steps" | wc -l)
        ;;
        *)
          logger -t LAVA " Unable to load collection $1"
          return 1
        ;;
     esac
     shift
  done
}



object_keys(){
 local key=""
 while [ $# -gt 0 ]
 do
   case "$1" in
    {|})
      shift
    ;;
    *:)
      key="$key "$(echo "$1" | awk -F ':' '{ print $1 }')
      shift
    ;;
    *)
      shift
    ;;
   esac
 done
 echo "$key" | tr '"' ' '
}
