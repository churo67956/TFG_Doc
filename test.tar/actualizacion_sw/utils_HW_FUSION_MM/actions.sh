. $TEST_SUITE_ROOT_PATH/utils/actions.sh
. $TEST_SUITE_ROOT_PATH/utils/background_action.sh
. $TEST_SUITE_ROOT_PATH/utils_$DUT/uci.sh


query_get(){
 local resp
 local status
 logger -t LAVA "GET $1"
 resp=$(wget -qO- "$1")
 logger -t LAVA "$resp"
 status=$(echo "$resp" | jsonfilter -e @.result )
 if ! [ "$status" = "pass" ]; then return 1; fi
 echo "$resp"
 return 0
}

fsm_reset(){
  local i=120
  local _RESERVATION_ID_;
  sleep 15
  logger -t LAVA reset
  logger -t LAVA $(uci_fsm $(uci_connector_name $1))
  if uci_fsm_check $1 available
  then
     return 0
  elif uci_fsm_check "$1" "waiting plug"
  then 
     while ! $( uci_fsm_check $1 available )
     do 
	sleep 10
     done
  elif uci_fsm_check $1 charging || uci_fsm_check $1 "waiting unplug" || uci_fsm_check $1 reserved || uci_fsm_check $1 standby
  then
     query_get "http://192.168.1.12:8906/webmanager"
     query_get "http://192.168.1.12:8906/webmanager/operator/system/startup?service=ocpp16&status=enable"
     query_get "http://192.168.1.12:8906/steve"
     query_get "http://192.168.1.12:8906/steve/chargepoint/add?chargeboxid=INGE-"`hostname`
     while [ "$(uci_ocpp_online)" = "false" ] &&  [ $i -gt 0 ]; do i=$(( i - 1 )); sleep 1; done
     if [ $i -gt 0 ]
     then 
       if uci_fsm_check $1 reserved
       then
         if [ -z "$_RESERVATION_ID_" ]; then _RESERVATION_ID_=$(uci_reservation_id $_CONNECTOR_NAME_); fi
         query_get "http://192.168.1.12:8906/steve/operations/v1.6/cancelreservation?chargepointlist=INGE-"`hostname`"&idexistingreservation=$_RESERVATION_ID_"
       elif uci_fsm_check $1 standby
       then
         query_get "http://192.168.1.12:8906/steve/operations/v1.6/changeavailability?chargepointlist=INGE-"`hostname`"&connectorid=0&availabilitytype=OPERATIVE"
       elif uci_fsm_check $1 charging || uci_fsm_check $1 "waiting unplug"
       then
         if [ -z "$_TRANSACTION_ID_" ]; then _TRANSACTION_ID_=$(uci_transaction_id $_CONNECTOR_NAME_) || true; fi;
         if [ -n "$_TRANSACTION_ID_" ]; then  query_get "http://192.168.1.12:8906/steve/operations/v1.6/remotestoptransaction?chargepointlist=INGE-"`hostname`"&idactivetransaction=$_TRANSACTION_ID_"; fi;
         query_get "http://192.168.1.12:8906/relay/off?relays=$_AC_PLUG_OUT_"
       fi
       return 0
     fi
     return 1
  fi
}

action_fsm_reset(){
  fsm_reset left || true
  fsm_reset right || true
}


query_post(){
 local resp
 local status
 logger -t LAVA "$2 -> $1"
 resp=$(curl --header "Content-Type: application/json" --request POST --data "$1" "$2")
 logger -t LAVA "$resp"
 status=$(echo "$resp" | jsonfilter -e @.result )
 if ! [ "$status" = "pass" ]; then return 1; fi
 echo "$resp"
 return 0
}


ocpp_wait_stop(){
  local i=280
  while [ "$(uci_ocpp_online)" = "true" ] &&  [ $i -gt 0 ]; do i=$(( i - 1 )); sleep 1; done
  if [ $i -eq 0 ]; then return 1; else return 0; fi;
}

