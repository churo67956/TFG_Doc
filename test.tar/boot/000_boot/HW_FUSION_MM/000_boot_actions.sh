#delegate the action to another device
. ${TEST_SUITE_ROOT_PATH}/utils_"$HW_VERSION"/actions.sh

A_000_boot_init(){ return 0; }
A_000_boot_end(){ 
 /etc/init.d/hmi start
}
A_check_hardware(){
 #start the script to check hw
 [ -f /etc/init.d/v2g ] || touch /etc/init.d/v2g
 chmod u+x $TEST_ROOT_PATH/check_hw
 . $TEST_ROOT_PATH/check_hw
 /etc/init.d/hmi stop || true
 killall hmi || true
 boot 
 #capture a screenshot
 chmod u+x $TEST_ROOT_PATH/fb2png
 $TEST_ROOT_PATH/fb2png
 #public the file
 mv fb.png /www
}

