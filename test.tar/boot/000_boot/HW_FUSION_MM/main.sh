set -x 
[ -f "$TEST_SUITE_ROOT_PATH/utils/main.sh" ] && . $TEST_SUITE_ROOT_PATH/utils/main.sh || exit 1
[ -f $TEST_SUITE_ROOT_PATH/utils_"$DUT"/"$DUT".sh ] && . $TEST_SUITE_ROOT_PATH/utils_"$DUT"/"$DUT".sh
[ -f $TEST_ROOT_PATH/"$TEST_CASE_NAME"_actions.sh ] && . $TEST_ROOT_PATH/"$TEST_CASE_NAME"_actions.sh
[ -f $TEST_ROOT_PATH/"$TEST_CASE_NAME"_results.sh ] && . $TEST_ROOT_PATH/"$TEST_CASE_NAME"_results.sh

trap lava_test_case INT TERM EXIT

#run the test case
main "$1"
