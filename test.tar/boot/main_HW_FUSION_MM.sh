#main entry point
. $TEST_SUITES_ROOT_PATH/$TEST_SUITE/utils/handler.sh

handler
