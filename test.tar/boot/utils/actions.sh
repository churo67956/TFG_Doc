set +x
#non action step
action_() { true; }
#check if an action finishes correctly
action_is_accepted() { [ $(get_value accepted "$_PIPE_") = "ok" ] && ( [ -z "$1" ] || [ $(get_value payload.result "$_PIPE_") = "$1" ] ) && return 0 || return 1; }
action_accepted() {  
   _PIPE_='{"accepted":"ok","payload":{"result":"'${1:-pass}'"'
   if [ -n "$2" ]
   then
    _PIPE_="$_PIPE_","$2";    
   fi  
   _PIPE_="${_PIPE_}"'}}'
}
action_rejected() {  _PIPE_='{"accepted":"error"}'; return 0; }
action_pass() {  action_is_accepted pass; }
