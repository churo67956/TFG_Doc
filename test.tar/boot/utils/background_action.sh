set +x

. "$TEST_SUITES_ROOT_PATH/$TEST_SUITE/utils/background_process.sh"

#run a block action
background_block_action() {
 #start a script in background
 background_action_start "script" "$1" "$2";
 #wait until it finish
 background_action_wait "$1" 180
}

#build and start a action in background
background_action_start() {
 local _script_
 #eval the action and build the response based in rc ( result code ) 
 _script_='output=$( eval '\'"$3"\'') && rc=0 || rc=1;'
 case $1 in
 command)
   _script_="$_script_"' response='\''{"accepted":"ok","payload":{"result":"'\''; [ $rc -eq 0 ] && response="$response"'\''pass"}}'\'' || response="$response"'\''fail"}}'\'';'
 ;;
 script)
   _script_="$_script_"' if [ $rc -ne 0 ]; then response='\''{"accepted":"error"}'\''; else response='\''{"accepted":"ok","payload":'\''${output:-'\''{"result":"pass"}'\''}'\''}'\'' ; fi;'
 ;;
 esac
 #run in background
 _background_process_start_ "$2" "$_script_"
}

#
background_action_wait() {  _background_process_wait_ "$1" "$2";_PIPE_=$(background_action_get_result "$1"); action_is_accepted; }
#stop an action
background_action_stop() {   _background_process_stop_ "$1";   }
#check if an action is running
background_action_is_finish() {   ! _background_process_is_running_ "$1" && return 0 || return 1;   }
#get action result
background_action_get_result() {     _background_process_get_result_ "$1";   }




