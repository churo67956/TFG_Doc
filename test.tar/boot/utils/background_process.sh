set +x

_background_process_pid_() {
  local PID
  [ -f  $LAVA_RESULT_DIR/results/$1/pid ] || return 1
  PID=$(cat $LAVA_RESULT_DIR/results/$1/pid) && [ -n $PID ] && echo $PID || return 1
}

_background_process_get_result_() {
  local result
  [ -f  $LAVA_RESULT_DIR/results/$1/result ] || return 1
  result=$(cat $LAVA_RESULT_DIR/results/$1/result) && [ -n $result ] && echo $result || return 1
}

_background_process_start_() {
 local NAME="$1"
 local result_dir="$LAVA_RESULT_DIR/results/$NAME"
 mkdir -p "$result_dir" 
 echo 'set -e;trap "exit" INT TERM;'"$2"'echo $response> '$LAVA_RESULT_DIR/results/$NAME/result   > $result_dir/bg_run.sh
 echo $result_dir/bg_run.sh
 $SHELL $result_dir/bg_run.sh &
 echo $! > $result_dir/pid
 return 0
}

_background_process_stop_(){
 if _background_process_is_running_ $1
 then
    local PID=$(cat $LAVA_RESULT_DIR/results/$1/pid)
    kill $PID > /dev/null 2>&1  || true
 fi
 return 0
}

_background_process_is_running_() {
  local PID
  [ -f  $LAVA_RESULT_DIR/results/$1/pid ] ||  return 1 
  PID=$(cat $LAVA_RESULT_DIR/results/$1/pid)
  [ -d /proc/$PID ] && return 0 || return 1
}

_background_process_wait_(){
  local SECONDS  PID
  ! _background_process_is_running_ "$1" && return 0
  PID=$(cat $LAVA_RESULT_DIR/results/$1/pid)
  SECONDS=$(date +'%s')
  while :
  do
    if [ $(( $(date +'%s') - $SECONDS )) -gt $2 ]
    then
      _background_process_stop_ $1
      echo "{\"accepted\":\"error\"}" > $LAVA_RESULT_DIR/results/$1/result
      return 1
    fi
    ! _background_process_is_running_ "$1" && return 0
    sleep 1
 done
}


_background_process_() {
 case $1 in
 start)
  shift
  _background_process_start_ "$1" "$2"
 ;;
 stop)
  shift
  _background_process_stop_ "$1"  
 ;;
 wait)
  shift
  _background_process_wait_ "$1" "$2" 
 ;;
 esac
}
