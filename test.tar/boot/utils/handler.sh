#main entry point
handler() {
 #current test case name
 local test_case;
 #iterate over all test cases current test suite
 for test_case in $TEST_CASES
 do
   #run each test cases in an independent env
   $SHELL -e -c "
    export TEST_CASE_NAME=${test_case}
    export TEST_CASE_ID=
    export TEST_CASE_RESULT=fail
    export MEASUREMENT=
    export STEP=0
    export FEEDBACK="starting..."
    export ROLE=
    export TEST_SUITE_ROOT_PATH=${TEST_SUITES_ROOT_PATH}/${TEST_SUITE}
    export TEST_ROOT_PATH=${TEST_SUITES_ROOT_PATH}/${TEST_SUITE}/${test_case}/$DUT
    exec $SHELL -e ${TEST_SUITES_ROOT_PATH}/${TEST_SUITE}/${test_case}/${DUT}/main.sh"
 done
 #always return 0 to continue with the next test suite
 return 0
}
