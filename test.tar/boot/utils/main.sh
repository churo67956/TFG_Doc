
set -x
#load some functions
. $TEST_SUITE_ROOT_PATH/utils/utils.sh
. $TEST_SUITE_ROOT_PATH/utils/model.sh
. $TEST_SUITE_ROOT_PATH/utils/steps.sh


#initialize the global variables
initialize(){
 export PIPE=""
 export RAW_MODEL=$( cat $TEST_ROOT_PATH/$TEST_CASE_NAME.json) #raw model
 local _js=$RAW_MODEL
 export ROLE=$(js_get role) 
 export TEST_CASE_ID=${TEST_CASE_NAME}
 #export hw_version collection from raw model
 model_get_collection collection=HW_VERSION
 if [ -f  $(eval echo $TEST_SUITE_ROOT_PATH/utils_"$HW_VERSION"/`eval echo $"HW_REST_"$HW_VERSION"_VERSION"`.sh) ]
 then
   . $(eval echo $TEST_SUITE_ROOT_PATH/utils_"$DUT"/`eval echo $"HW_REST_"$HW_VERSION"_VERSION"`.sh)
 fi
}

main(){
 local _js=""
 local _steps="" #global local variable for store steps
 local _step="" #a local step
 local _stscounter=1 #global local counter for steps
 local _stsmax=0
 logger -t LAVA  "TEST CASE : $TEST_CASE_NAME"
 #set global variables
 initialize
 TEST_CASE_RESULT="fail" #fail by default
 model_get_collection collection=steps #steps all steps
 while steps_next #get current step
 do
   STEP=$_stscounter
   logger -t LAVA " step $(( _stscounter - 1 ))"
   step_run "step=$_step" #run the step
 done
 TEST_CASE_RESULT="pass" #test case correct
 #exit with success
 exit 0
}

