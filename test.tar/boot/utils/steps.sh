

steps_next(){
  if [ $_stscounter -le $_stsmax ]
  then
    _step=$(echo "$_steps" | head -n $_stscounter | tail -n 1)
    _stscounter=$(( _stscounter + 1 ))
    return 0
  else
    return 1
  fi 
}


step_run(){
  local _action
  local _results
  local result
  local rescounter=1
  local _resmax=0
  local _step=""
  while [ $# -gt 0 ]
  do
    case "$1" in
      step=*)
          _step="$(echo "$1" | awk -F "{" '{print "{"$2}')"
          model_get key=action
          logger -t LAVA "`eval echo ${_action:-no expected action}`"
          if [ -n "$_action" ] && ! eval "$_action"
          then 
              logger -t LAVA " An error happend during action=`eval echo $_action` execution"
              return 1
          fi
          model_get key=results #also updates _resmax
          while [ $rescounter -le $_resmax ]
          do
             result=$(echo "$_results" | head -n $rescounter | tail -n 1)
             logger -t LAVA "`eval echo ${result:-no expected result}`"
             if [ -n "$result" ] && ! eval "$result"
             then
                logger -t LAVA " An error happend during result=`eval echo $result` execution"
                return 1
             fi
             rescounter=$(( rescounter  +  1 ))
          done
      ;;
      *)
        return 1
      ;;
    esac
    shift
  done 
}

duty_run(){
  local duties=$(echo "$*" | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g")
  [ -z "$duties" ] && return 0
  echo "$duties"
}
