R_HW_FUSION_MM_fsm(){
 local outlet
 local fsm
 local fsm_current
 while [ $# -gt 0 ]
 do
   case "$1" in
    outlet=*)
      outlet=$(echo "$1" | awk -F "=" '{print $2}')
    ;;
    fsm=*)
      fsm="$(echo "$1" | awk -F "=" '{print $2}' | sed -e "s/\../ /g")"
      logger -t LAVA "R_HW_FUSION_MM_fsm outlet=$outlet fsm=$fsm"
      fsm_current="$(ubus call `hostname` get_status | jsonfilter -e "@.`eval echo '$'$outlet`.state")"
      if [ "$fsm" = "$fsm_current" ]
      then
         return 0
      fi
      while [ "$(ubus call `hostname` get_status | jsonfilter -e "@.`eval echo '$'$outlet`.state")" = "waiting plug" ]
      do 
        sleep 1
      done
     ;;
     *)
       return 1
     ;;
   esac
   shift
 done 
}

R_HW_FUSION_MM_tag(){
 while [ $# -gt 0 ]  
 do
   case "$1" in
    validation=*)
       logger -t LAVA "R_HW_FUSION_MM_tag validation=${1:11}"
     ;;
     *)
       return 1
     ;;
   esac
   shift
 done
}
R_HW_FUSION_MM_power(){
 logger -t LAVA "R_HW_FUSION_MM_power"
}
