js_get() {
  local value
  local key=$1
  shift
  value=$(echo "$_js" | jsonfilter -e '@.'"$key")
  if  [ -n "$value" ]
  then
    echo "$value"
    return 0
  fi
  return 1
}

js_collection_get(){
  echo "$1" | jsonfilter -e @."$2"[*]
}

