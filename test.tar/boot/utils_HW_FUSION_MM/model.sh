
model_object_load(){
  local exports=""
  local version=$(eval echo $(js_get VERSION | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g"))
  local keys=$(object_keys $_js)
  for key in $keys
  do
    exports="$exports -e 'HW_"$version"_"$key"=@."$key"'"
  done
  eval jsonfilter -s "'"$_js"'" "$exports" | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g"
}
