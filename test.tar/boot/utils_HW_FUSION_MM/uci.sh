uci_reservation_id(){
 local id
 id=$(uci show  `hostname`o.$(uci_connector_name $1).reservation_id | awk -F"'" '{print $2}') && [ -n "$id" ] && echo "$id" || return 1
}
uci_transaction_id() {
 local id
 id=$(uci show `hostname`o.$(uci_connector_name $1).transaction_id | awk -F"'" '{print $2}') && [ -n "$id" ] && echo "$id" || return 1
}
uci_power_meter() {
 local power
 power=$(uci show chargingpointd_rt.$(uci_connector_name $1).power | awk -F"'" '{print $2}') && [ -n "$power" ] && echo "$power" || return$
}
uci_connector_name() {
  uci show accontroller$1.internal.logical_connector | awk -F"." '{print substr($4,1,length($4)-1)}'
}
uci_fsm() {
  ubus call `hostname` get_status | jsonfilter -e @.$1.state
}
uci_fsm_check() {
 local fsm="$(uci_fsm $(uci_connector_name $1))"
 if ! [ "$fsm" = "$2" ]
 then
     while [ "$(uci_fsm $(uci_connector_name $1))" = "waiting plug" ] 
     do
         sleep 10
     done
     fsm="$(uci_fsm $(uci_connector_name $1))"
     if ! [ "$fsm" = "$2" ]; then return 1; fi
 fi  
 [ -z "$3" ] && return 0
 if [ "$_CONNECTOR_NAME_" = "left" ]; then  uci_fsm_check "right" "$3"; return 0; fi;
 if [ "$_CONNECTOR_NAME_" = "right" ]; then  uci_fsm_check "left" "$3"; return 0; fi;
}

uci_ocpp_online() {
   echo "$( ubus call `hostname` get_status | jsonfilter -e @.ocpp.*.online )"        
   return 0
}

