#delegate the action to another device
. ${TEST_SUITE_ROOT_PATH}/utils_"$HW_VERSION"/actions.sh

A_000_boot_init(){
 logger -t LAVA "A_000_boot_init"
}
A_000_boot_end(){
 logger -t LAVA "A_000_boot_end"
}
A_check_hardware(){
 logger -t LAVA "A_check_hardware"
 #stop hmi
 /etc/init.d/hmi stop || true
 killall hmi || true
 #start the script to check hw
 [ -f /etc/init.d/v2g ] || touch /etc/init.d/v2g
 chmod u+x $TEST_ROOT_PATH/check_hw
 . $TEST_ROOT_PATH/check_hw
 boot 
 #capture a screenshot
 chmod u+x $TEST_ROOT_PATH/fb2png
 $TEST_ROOT_PATH/fb2png
 #public the file
 mv fb.png /www
}

A_wait(){
 logger -t LAVA "A_wait"
 action_rejected
 pgrep hmi || /etc/init.d/hmi start 
 sleep 20
 pgrep hmi
 action_accepted
}
