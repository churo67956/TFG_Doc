#delegate the action to another device
[ -f $TEST_SUITE_ROOT_PATH/utils_"$HW_VERSION"/results.sh ]  && . $TEST_SUITE_ROOT_PATH/utils_"$HW_VERSION"/results.sh

R_check_hardware_ok(){
 logger -t LAVA "R_check_hardware_ok"
 rest_HW_FUSION_MM_hander method=check_hardware
}
