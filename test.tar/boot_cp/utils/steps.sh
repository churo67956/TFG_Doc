

steps_next(){
  if [ $_stscounter -le $_stsmax ]
  then
    _step=$(echo "$_steps" | head -n $_stscounter | tail -n 1)
    _stscounter=$(( _stscounter + 1 ))
    return 0
  else
    return 1
  fi 
}


step_run(){
  local action
  local results
  local result
  local rescounter=1
  local resmax=0
  while [ $# -gt 0 ]
  do
    case "$1" in
      step=*)
          _js="$(echo "$1" | awk -F "{" '{print "{"$2}')"
          action="$(model_get key=action)"
          if [ -n "$action" ] && ! eval "$action"
          then 
              logger -t LAVA " An error happend during action=$action execution"
              return 1
          fi
          results="$(model_get key=results)" #also updates _resmax
          resmax=$(echo "$results" | wc -l)
          while [ $rescounter -le $resmax ]
          do
             result=$(echo "$results" | head -n $rescounter | tail -n 1)
             if [ -n "$result" ] && ! eval "$result"
             then
                logger -t LAVA " An error happend during result=$result execution"
                return 1
             fi
             rescounter=$(( rescounter  +  1 ))
          done
      ;;
      *)
        return 1
      ;;
    esac
    shift
  done 
}

duty_run(){
  local duties=$(echo "$*" | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g")
  [ -z "$duties" ] && return 0
  echo "$duties"
}
