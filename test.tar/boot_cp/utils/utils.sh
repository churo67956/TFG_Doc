set +x
#evaluate a function saving her name
fn() {   _FEEDBACK_="$1";   eval $*;   }

_flow_test_case_result_unknown_='_TEST_CASE_RESULT_=unknown; return 1;'

_flow_test_case_result_fail_='_TEST_CASE_RESULT_=fail; return 1;'

_flow_test_case_result_pass_='_TEST_CASE_RESULT_=pass; return 1;'

remove_white_spaces() { echo $* | sed -e 's/ //g'; }

remove_slash() {  echo $* | sed -e 's/\\//g'; }

json_to_string() {   remove_white_spaces $* | sed  's/"/\\"/g' | sed 's/{/\\{/g' | sed  's/}/\\}/g';  }


#exit  handler
lava_test_case() {
  local rc=$?
  local command='lava-test-case "$_TEST_CASE_ID_" --result '"${TEST_CASE_RESULT:-fail}"
  if [ -n "$_MEASUREMENT_" ]; then  command="$command"'--measurement '"$_MEASUREMENT_"; fi;
  eval "$command"
  lava_test_event
  if [ "$TEST_CASE_RESULT" = "fail" ];
  then 
      #if the error happend during the end action !!!
      model_run_action action=end 
  fi;
  logger -t LAVA "end test case: $_TEST_CASE_NAME_"
  return 0
}

#
lava_test_event() {
 local msg;
 msg='{"lavaTestCaseId":"'$TEST_CASE_ID'","result":"'$TEST_CASE_RESULT'"'
 if ! [ "$_TEST_CASE_RESULT_" = "pass" ]
 then
  msg="$msg"',"step":"'$_STEP_'"'
 fi
 msg="$msg"'}'
 lava-test-event "$msg"
 logger -t LAVA "event $msg"
 sleep 4
}

attemps() {
 local a=3;local f=$1;local n=$2
 shift;shift
 while [ $a -gt 0 ]
 do
   $f $n  "$*" && return 0
   sleep 30
   a=$(( $a - 1 ))
 done
 return 1
}


