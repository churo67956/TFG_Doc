#delegate the action to another device
. ${TEST_SUITE_ROOT_PATH}/utils_"$HW_VERSION"/actions.sh

A_ntp_server_init(){ return 0; }
A_ntp_server_end(){ return 0; }
A_ntp_server_sync(){
 case "$1" in
   server=*)
     ntpd -qn -p $(echo "$1" | awk -F "=" '{print $2}')
   ;;
   *)
    logger -t LAVA " Parameter $1 not supported"
    return 1
   ;;
 esac
}


