#delegate the action to another device
. ${TEST_SUITE_ROOT_PATH}/utils_"$HW_VERSION"/actions.sh

A_ntp_webmanager_init(){ return 0; }
A_ntp_webmanager_end(){ return 0; }
A_ntp_webmanager_sync(){
 rest_HW_FUSION_MM_handler  method=system_sync
}


