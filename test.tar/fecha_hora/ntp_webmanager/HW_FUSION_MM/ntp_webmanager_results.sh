#delegate the action to another device
[ -f $TEST_SUITE_ROOT_PATH/utils_"$HW_VERSION"/results.sh ]  && . $TEST_SUITE_ROOT_PATH/utils_"$HW_VERSION"/results.sh

R_ntp_webmanager_sync(){
 local remote_dtt
 _js="$PIPE"
 remote_dtt=$(js_get datetime)
 local_dtt=$(date +%s)
 result_check_measurement $local_dtt $remote_dtt 120
}
