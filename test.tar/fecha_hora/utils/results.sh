set +x
#non expect step
results_() { true; }
#sync default behavour
result_pass() {   
 local "_result_";
 if [ $(get_value payload.result "$_PIPE_") = "pass" ]
 then 
   _result_="pass";
 else
  _result_="fail";
 fi
 result_validator "$1"
}


result_validator () {
 local config_result
 [ -z "$1" ] && config_result="pass" || config_result="$1"
 if [ "$config_result" = "$_result_" ] 
 then
    _TEST_CASE_RESULT_="pass"
  else
    _TEST_CASE_RESULT_="fail"
    return 1
 fi
}

result_check_measurement(){
  local "real" "expected" "error" "max_error";
  real="$1"
  expected="$2"
  max_error="$3";
  if [ $(( expected - real )) -gt 0 ]; then error=$(( expected - real )); else error=$(( real -  expected )); fi
  _MEASUREMENT_=$error
  if [ $error -le $max_error ]; then _result_="pass"; else _result_="fail"; fi;
  return 0
}
