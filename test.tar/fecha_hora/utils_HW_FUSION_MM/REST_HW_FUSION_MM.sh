rest_get(){
 local resp
 logger -t LAVA "GET $1"
 _js=$(wget -qO- "$1")
 logger -t LAVA "$_js"
 if ! [ "$(js_get result)" = "pass" ]; then return 1; fi
 echo "$_js"
 return 0
}

rest_post(){
 local resp
 local status
 logger -t LAVA "$2 -> $1"
 _js=$(curl --header "Content-Type: application/json" --request POST --data "$1" "$2")
 logger -t LAVA "$_js"
 echo "$_js"
 if ! [ "$(js_get result)" = "pass" ]; then return 1; fi
 return 0
}

rest_HW_FUSION_MM_handler(){
 local action="$1"
 shift
 local payload=$*
 case "$action" in
   method=swip)
     rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/rfid?$1") >/dev/null
   ;;
   method=relays)
     shift
     case "$1" in
      action=on)
        rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/relay/on?$1") >/dev/null
      ;;
      action=off)
        rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/relay/off?$1") >/dev/null 
      ;;
     esac
   ;;
   method=check_hardware)
      rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/ocr") >/dev/null
   ;;
   method=system_sync)
      rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/webmanager") >/dev/null
      PIPE=$(rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/webmanager/operator/system/system/sync"))
      rest_get $(eval echo $"HW_REST_"$HW_VERSION"_service/webmanager/logout") >/dev/null
   ;;
 esac  
} 
