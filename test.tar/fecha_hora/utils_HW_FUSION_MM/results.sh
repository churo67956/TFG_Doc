. $TEST_SUITE_ROOT_PATH/utils/results.sh


alias results_accepted="action_pass"
