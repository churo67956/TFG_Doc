#{ "VERSION": "PROXMARK3", "UID": "DEADBEEF" }
set +x
#set -x

TEST_CASE=boot
HW_VERSION=HW_FUSION_MM
. ./"$HW_VERSION".sh
. ./PROXMARK3.sh
. ./SIMULATOR_AC.sh
. ./BOOT.sh
. ./REST_"$HW_VERSION".sh


hw_has_connectors(){
  local str='export HW_"$HW_VERSION"_conn="'
  case "$*" in
   *left*)
      str="$str"left
    ;;
  esac
  case "$*" in
   *right*)
     str="$str right"
   ;;
  esac
  str=$str'"'
  echo $*$str
}

hw_collection_load(){
  local exports=""
  exports=$(echo "$*" | while read obj
  do
     hw_object_load  "$obj"
  done | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g")
  exports="$(hw_has_connectors "$exports")"
  eval "$exports"
}

object_keys(){
 local key=""
 while [ $# -gt 0 ]
 do
   case "$1" in
    {|})
      shift
    ;;
    *:)
      key="$key "$(echo "$1" | awk -F ':' '{ print $1 }')
      shift
    ;;
    *)
      shift
    ;;
   esac
 done
 echo "$key" | tr '"' ' ' 
}


hw_object_load(){
  local exports=""
  local object="$*"
  local version=$(eval echo $(echo "$object" | jsonfilter -e @.VERSION | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g")) 
  local keys=$(object_keys $object) 
  for key in $keys
  do
    exports="$exports -e 'HW_"$version"_"$key"=@."$key"'"    
  done
  echo "$exports"
  eval jsonfilter -s "'"$object"'" "$exports"
}

duty_run(){
  local duties=$(echo "$*" | sed -e "s/##/\"$/g" | sed -e "s/#/\"/g")
  [ -z "$duties" ] && return 0
  eval "$duties"
}


#load the steps.json
RAW_MODEL=`cat steps.json`
#load HW variables
RAW_HW=$(echo "$RAW_MODEL" | jsonfilter -e @.HW_VERSION[*] )
set -x
hw_collection_load "$RAW_HW"
echo $HW_HW_FUSION_MM_conn
set +x
exit 0

#steps
STEPS=$(echo "$MODEL" | jsonfilter -e @.steps[*])
echo "$STEPS" | while read step
do
  echo  $step
  action=$(echo $step | jsonfilter -e @.action)
  duty_run $action
  counter=0
  while :
  do 
    result=`echo $step | jsonfilter -e @.results[$counter]` || true
    [ -z "$result" ] && break
    duty_run "$result"
    counter=$(( counter + 1 ))
  done
done
#set +x
