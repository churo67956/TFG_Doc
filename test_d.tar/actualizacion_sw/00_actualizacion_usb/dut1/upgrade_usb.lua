require "ubus"
require "uloop"

check = function(msg)
      for k, v in pairs(msg) do
        if tostring(k) == "status"
        then
            if tostring(v) == "file errors" or tostring(v) == "no directory found"
            then
	        conn:close()
                os.exit(1)
            elseif tostring(v) == "up-to-date" or tostring(v) == "ok"
            then
	        conn:close()
                os.exit(0)
            end
        end
      end
end

local my_events = {
    ["6S0A182C0002.update_from_local_dir"] = check,
    ["6S0A182C0002.installed"] = check
}

uloop.init()
conn = ubus.connect()
if not conn then
  error("Failed to connect to ubus")
end
conn:listen(my_events)
uloop.run()
