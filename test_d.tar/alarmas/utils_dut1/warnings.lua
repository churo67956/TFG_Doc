require "ubus"
require "uloop"

params = { ... }
-- evento a escuchar
warning_event = params[1]
warning_type = params[2]
--- validador
warning_status = params[3]

target = nil

local default_handler = function(msg)
   conn:close()
   for k, v in pairs(target) do
      --print("clave "..k.." valor "..tostring(msg[k]))
      if ( msg[k] == nill or tostring(msg[k]) ~= tostring(v) )
      then
        --print("default es distinto: esperado : ".. v .." leido ".. tostring(msg[k]))
      os.exit(1)
      end
   end
   os.exit(0)
end
if warning_type == "open_door"
then
  target = {warnings="11 - open door",onoff=warning_status} 
elseif warning_type == "pilot_shortcircuit"
then
 target = {warnings="15 - control pilot shortcircuit",onoff=warning_status} 
end 

local my_event = {
  [warning_event] = default_handler
}
uloop.init()
conn = ubus.connect()
if not conn then
  error("Failed to connect to ubus")
end
conn:listen(my_event)
uloop.run()


