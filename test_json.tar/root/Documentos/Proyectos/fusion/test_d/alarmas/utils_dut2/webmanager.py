import os
import sys
import time
import json
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from configparser import ConfigParser
from collections import OrderedDict

def go_to(a1,a2):
  wait = WebDriverWait(driver, 10) 
  #hover over system menu
  systemmenu = driver.find_element_by_xpath(a1)
  actions = ActionChains(driver)
  actions.move_to_element(systemmenu).perform()
  #click onto system submensu
  wait.until(EC.element_to_be_clickable((By.XPATH,a2))).click()
  time.sleep(2)

#return 1 pass , return 0 is not fail is unknown
def sync_with_browser():
  global exitcode
  exitcode=1
  syncb =  driver.find_element_by_xpath(config["system_system"]["sync_btn"])
  syncb.click()
  start_time=time.time() 
  while round((time.time() - start_time)) < 30:
    if syncb.get_attribute('value') != config["system_system"]["sync_label"]:
      exitcode=0
      return 1
    time.sleep(2)
  return 0

#return 1 pass , return 0 is not fail is unknown
def system_service_on_off(state):
  global exitcode
  #2 states
  init_state=config["system_services"][state]
  if state == "enable":
    end_state=config["system_services"]["disable"]
  else:
    end_state=config["system_services"]["enable"]
  start_time=time.time() 
  #enable
  exitcode=1
  while round((time.time() - start_time)) < 60:
    try:
      disable = driver.find_element_by_xpath(config["system_services"][query["action"]["service"]])
      if disable.get_attribute('value') == init_state:
        #print("init state", init_state)
        disable.click()
  #wait some time
      if disable.get_attribute('value') == end_state:
        #print("end state", end_state)
        exitcode=0
        return 1
    except Exception as e:
        time.sleep(2)
  return 0

def system_services():
   #global query
   if query["action"]["state"] == "restart":
      if not system_service_on_off("disable"):
         return 0
      if system_service_on_off("enable"):
         print_result("pass")
   else:
      if system_service_on_off(query["action"]["state"]):
         print_result("pass")

def app_upgrade():
    upgradebtn =driver.find_element_by_xpath(config["upgrade"]["upgrade_btn"])
    upgradebtn.click()
    time.sleep(2)
    while driver.find_element_by_xpath('//*[@id="apply"]').is_displayed():
        time.sleep(10)
        spanel=driver.find_element_by_xpath('//*[@id="success"]').is_displayed()
        epanel=driver.find_element_by_xpath('//*[@id="error"]').is_displayed()
        if epanel or spanel:
            if epanel:
                print_result("fail")
            else:
                print_result("pass")
            return 1
    print_result("fail")
    return 1

def print_result(result):
  print("{\"result\":\""+result+"\"}")


def login():  
 #Login first
  driver.get(query["url"])
 #insert user name
  useri= driver.find_element_by_xpath(config["login"]["user"])
  useri.clear()
  useri.send_keys('')
  useri.send_keys(query["login"]["user"])
 #insert password
  passwi = driver.find_element_by_xpath(config["login"]["password"])
  passwi.clear()
  passwi.send_keys('')
  passwi.send_keys(query["login"]["password"])
 #login action
  loginb = driver.find_element_by_xpath(config["login"]["btn"])
  loginb.click()

exitcode=0
driver=None
try:
  config=ConfigParser()
  config.read(sys.argv[2])
  query=json.loads(sys.argv[1], object_pairs_hook=OrderedDict)
#start firefox
  driver=webdriver.Firefox()
#login
  login()
#select action  
  if query["action"]["name"] == "login":
      print_result("pass") 
  elif query["action"]["name"] == "system_sync_with_browser":
      go_to(config["mainviews"]["system"],config["system"]["system"])
      sync_with_browser()
  elif query["action"]["name"] == "system_services":
     go_to(config["mainviews"]["system"], config["system"]["services"])
     system_services()
  elif query["action"]["name"] == "app_upgrade":
     go_to(config["mainviews"]["app"], config["app"]["upgrade"])
     app_upgrade()     
except Exception as e:
  exitcode=1
if driver is not None:
 driver.close()
 driver.quit()
sys.exit(exitcode)
