#fecha_hora
##ntp_server
ntp_server_ip=192.168.1.12
