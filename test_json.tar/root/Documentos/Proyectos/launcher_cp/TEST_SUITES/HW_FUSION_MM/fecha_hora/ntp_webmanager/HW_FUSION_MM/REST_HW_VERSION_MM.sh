. ${_TEST_SUITE_ROOT_PATH_}/utils_"$HW_VERSION"/REST.sh


A_REST_HW_FUSION_MM_controller(){
   case "$1") in
      method=system_sync)
          A_REST_HW_FUSIOIN_MM_controller_system_sync $*
      ;;
   esac
}


A_REST_HW_FUSIOIN_MM_controller_system_sync(){
   REST_get http://192.168.1.12:8906/webmanager
   REST_get http://192.168.1.12:8906/webmanager/operator/system/system/sync
   REST_get http://192.168.1.12:8906/webmanager/logout
}
