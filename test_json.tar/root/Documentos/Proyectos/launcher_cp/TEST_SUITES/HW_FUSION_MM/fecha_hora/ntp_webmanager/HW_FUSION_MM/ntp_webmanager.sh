. ${_TEST_SUITE_ROOT_PATH_}/utils/utils_"$HW_VERSION"/model.sh

ntp_webmanager_init(){
  export _RAW_MODEL_=`cat $_TEST_ROOT_PATH_/steps.json`
  RAW_HW=$(echo "$_RAW_MODEL_" | jsonfilter -e @.HW_VERSION[*] )
  hw_collection_load "$RAW_HW"
}
