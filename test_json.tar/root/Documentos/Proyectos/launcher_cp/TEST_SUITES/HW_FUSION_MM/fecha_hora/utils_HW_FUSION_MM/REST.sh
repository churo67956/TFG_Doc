
. ${_TEST_SUITE_ROOT_PATH_}/utils_"$HW_VERSION"/js.sh

REST_get(){
 local resp
 local status
 logger -t LAVA "GET $1"
 resp=$(wget -qO- "$1")
 logger -t LAVA "$resp"
 status=$(js_get result $resp)
 echo "$resp"
 if ! [ "$status" = "pass" ]; then return 1; fi
 return 0
}

REST_post(){
 local resp
 local status
 logger -t LAVA "$2 -> $1"
 resp=$(curl --header "Content-Type: application/json" --request POST --data "$1" "$2")
 logger -t LAVA "$resp"
 status=$(js_get result $resp)
 echo "$resp"
 if ! [ "$status" = "pass" ]; then return 1; fi
 return 0
}
