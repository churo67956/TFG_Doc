
set +e

SET_UP_ROOT_PATH=${SET_UP_ROOT_PATH:-`pwd`}
. $SET_UP_ROOT_PATH/utils/globals.sh
. $SET_UP_ROOT_PATH/utils/utils.sh
. $SET_UP_ROOT_PATH/utils/loads.sh
. $SET_UP_ROOT_PATH/utils/test_cases.sh
. $SET_UP_ROOT_PATH/utils/lava.sh

trap "publisher" INT TERM EXIT

main() {
 local paths=""
 local hw_version=$( cat "$SET_UP_ROOT_PATH/configs/rt.json" | jq .HW_VERSION | xargs echo )
 local test_cases=$( cat "$SET_UP_ROOT_PATH/configs/rt.json" | jq .TEST_CASES | xargs echo )
 [ -n "$hw_version" ] && [ -n "$test_cases" ] || ( logger "LAVA: No HW_VERSION nor TEST_CASES fount." && return 1 )
 #check if the  test cases scaffolding is correct
 paths=$(test_cases_check "$hw_version" $test_cases) || return 1
 #deploy the test cases to all the  devs
 test_cases_deploy "$hw_version" "$paths"
 #send the  job to LAVA
 lava_submit_job "$paths" 
}

main
