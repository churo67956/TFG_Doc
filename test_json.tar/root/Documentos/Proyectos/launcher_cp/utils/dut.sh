#creacion del modelo
model_dut() {
 local device_id
 device_id=$(table_row "$1" "${CHARGEPOINTS[@]}")
 if [ -n "$device_id" ]
 then
    device_id=$(row_cell 2 "$device_id")
 else
   device_id="$1"
 fi
 table_row "$device_id" "${DUTS[@]}" 
# existe la posibilidad de que no exista el dut en la coleccion
# [ $? -eq 0 ] || return 200
}

## MODEL
dut_name() {
 row_cell 1 "$1" 
}
dut_user() {
 row_cell 2 "$1" 
}
dut_ip() {
 row_cell 3 "$1" 
}
dut_pass() {
 row_cell 4 "$1" 
}
dut_key() {
 row_cell 5 "$1" 
}
dut_os() {
 row_cell 6 "$1" 
}
dut_prompt() {
 row_cell 7 "$1"
}
dut_worker() {
 row_cell 8 "$1" 
}

dut_add_to_lava() {
  local dut;local remote_duts;local remote_types;local model
  remote_types=$(lava-server manage device-types list)
  [ $? -eq 0 ] || return 200
#$(error_handler "Error: Imposible obtener el listado de tipos de dispositivo")
  remote_types=$(echo $remote_types | tr '\n' ' ')  
  remote_duts=$(lava-server manage devices list)
  [ $? -eq 0 ] || return 201
#$(error_handler "Error: Imposible obtener el listado de dispositivos")
  remotes_duts=$(echo $remoe_duts | tr '\n' ' ')
  for dut in ${!test_cases_per_dut[@]}
  do
    model=$(model_dut "$dut")
    echo $model
    dut=$(dut_name "$model")
    echo $dut
    if [[ $remote_duts != *"$dut"*  ]]
    then
     #comprobar que no existe  el type
      if [[ $remote_types != *"$dut-ssh"*  ]]
      then
        #agregar el type
         echo -e "$DEVICE_TYPE_TEMPLATE" > $LAVA_TEMPLATE_ROOT_PATH/device-types/$dut-ssh.jinja2
         chown lavaserver:lavaserver $LAVA_TEMPLATE_ROOT_PATH/device-types/$dut-ssh.jinja2
         lava-server manage device-types add $dut-ssh || return 202
#$(error_handler "Error: Imposible agregar el tipo de dispositivo $dut en lava")
      fi
     #agregar el dut
     lava-server manage devices add --device-type "$dut-ssh" --worker  $(dut_worker "$model") $dut || return 203
    fi
    echo -e "{% extends '"$dut"-ssh.jinja2' %}\n{% set ssh_host = ssh_host | default('"$(dut_ip "$model")"') %}\n{% set ssh_identity_file = 'dynamic_vm_keys/lava' %}"  > "$LAVA_TEMPLATE_ROOT_PATH/devices/$dut.jinja2"
    chown lavaserver:lavaserver "$LAVA_TEMPLATE_ROOT_PATH/devices/$dut.jinja2"
#$(error_handler "Error: Imposible agregar el dispositivo $dut en lava")
    lava-server manage devices update --health GOOD $dut || return 204
#$(error_handler "Error: Imposible actualizar el estado de $dut a GOOD")
  done
}

