error_handler() {
 echo $1
 exit 1
}
