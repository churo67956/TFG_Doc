#global variables
TEST_SUITES_ROOT_PATH=${SET_UP_ROOT_PATH}/TEST_SUITES
TAR_ROOT_PATH=/tmp/tarballs
LAVA_USER=super
LAVA_SERVER_IP=192.168.1.12
LAVA_TEST_ROOT_PATH=/tmp/test-cases
LAVA_TEMPLATE_ROOT_PATH=/etc/lava-server/dispatcher-config
LAVA_TOKEN=xrx3izlzwk0w7qsiz5idk00hqe1sooyz0263ze2fphre0ia0gb6gptryurqeznf0pyaln3uumw41b4aecm35tstima0808j084jh4bnu2jwomyne8lxrch9bmpsz2cc6
DEVICE_TYPE_TEMPLATE="{% extends 'base.jinja2' %}
{% block body %}
actions:
  deploy:
    connections:
      serial:
    methods:
      ssh:
        options:
{{ ssh_options }}
        # primary connections get this from the device dictionary.
        # secondary connections get this from the lava-multinode protocol support.
        host: \"{{ ssh_host|default('') }}\"
        port: {{ ssh_port|default(22) }}
        user: \"{{ ssh_user|default('root') }}\"
        identity_file: \"{{ ssh_identity_file }}\"
  boot:
    connections:
      serial:
    methods:
      ssh:
{% endblock body %}"

#some validation
[ -d $SET_UP_ROOT_PATH/jobs ] && rm -r -f $SET_UP_ROOT_PATH/jobs
mkdir -p $SET_UP_ROOT_PATH/jobs
if ! [ -d $TEST_SUITES_ROOT_PATH ]; then logger "LAVA: test suites path not found at $TEST_SUITES_ROOT_PATH"; exit 1; fi
mkdir -p $TAR_ROOT_PATH
if ! [ -d $LAVA_TEMPLATE_ROOT_PATH ]; then logger "LAVA: lava templates root path not found at $TEST_SUITES_ROOT_PATH"; exit 1; fi
