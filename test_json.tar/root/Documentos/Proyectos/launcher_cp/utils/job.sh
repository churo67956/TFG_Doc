lava_create_devices(){
 local model
 while [ $# -gt 0 ]
 do
  model=(model_find duts HW_VERSION=$1)
  if ! ( lava-server manage device-types list | tr '\n' ' ' |  grep $1-ssh ) 
  then
    echo -e "$DEVICE_TYPE_TEMPLATE" > $LAVA_TEMPLATE_ROOT_PATH/device-types/$1-ssh.jinja2
    chown lavaserver:lavaserver $LAVA_TEMPLATE_ROOT_PATH/device-types/$1-ssh.jinja2
    if ! lava-server manage device-types add $1-ssh
    then
      logger "LAVA: Unable to load $1-ssh device"
      return 1
    fi
  fi
  if ! ( lava-server manage devices list | tr '\n' ' ' | grep $1 )
  then
    echo -e "{% extends '"$1"-ssh.jinja2' %}\n{% set ssh_host = ssh_host | default('"$(echo $model | jq. IP)"') %}\n{% set ssh_identity_file = 'dynamic_vm_keys/lava' %}"  > "$LAVA_TEMPLATE_ROOT_PATH/devices/$1.jinja2"
    chown lavaserver:lavaserver "$LAVA_TEMPLATE_ROOT_PATH/devices/$1.jinja2"
    if ! ( lava-server manage devices add --device-type "$1-ssh" --worker  $(echo $model | jq .WORKER) $1  )
    then
       logger "LAVA: Unable to add $1 device"
       return 1
    fi
    if ! ( lava-server manage devices update --health GOOD $1 ) 
    then
      logger "LAVA: Unabe to update $1 device heath"
      return 1
    fi
  fi
 done
}

lava_submit_job(){
  local model=""
  local tsc=""
  local tsp=""
  local tcl=""
  local tcps=$(echo -e "$*" | awk -F '|' '{print $0}' | sort)
  local devs=$(echo -e "$*" | awk -F '|' '{print $1}' | sort)
  for dev in "$devs"
  do
    model=$(model_find duts HW_VERSION=$dev)
    job="device_type: "$dev"-ssh
job_name: Primary connection on fecha-hora.yaml
timeouts:
  job:
    hours: 8
  action:
    hours: 8
  connection:
    hours: 2
  actions:
    lava-test-shell:
      hours: 6
priority: medium
visibility: public
actions:
- deploy:
    to: ssh
    os: "$(echo $model | jq .OS)"
- boot:
    method: ssh
    failure_retry: 1
    prompts:
    - "$(echo $model | jq .PROMPT)"
- test:\n    failure_retry: 1
    definitions:"
    for tcp in "$tcps"
    do
      case "$tcp" in
      *"$dev"*)
         tsc=$(echo "$tcp" | awk -F '/' '{print $(( NF - 1 ))}')
         case $tsc in
         $tsp) #same test suite
           tcl"=$tcl"$(echo "$tcp" | awk -F '/' '{print $NF }')
         ;;
         *) #new test suite
           if [ -n "$tcl ];
           then
            job="$job"'
    - repository:\n 
        metadata:\n
          format: Lava-Test Test Definition 1.0\n
          name: testing-test-case\n
          description: first connection lava-test-case\n
        run:\n
          steps:\n
          - export DUT='$dev'\n
          - export TEST_SUITES_ROOT_PATH='$LAVA_TEST_ROOT_PATH'\n
          - export TEST_SUITE='"$tsc"'\n
          - export TEST_CASES="'"$tcl"'"\n
          - $SHELL $TEST_SUITES_ROOT_PATH/$TEST_SUITE/main_'"$dev"'\n
      from: inline\n
      name: '"$tsc"'\n
      path: inline/'$tsc'.yaml\n'
           fi
           tcl"=$tcl"$(echo "$tcp" | awk -F '/' '{print $NF }')
         ;;
         esac
      ;;
      esac
    done
    echo  "$job" > "$SET_UP_ROOT_PATH/jobs/0_$dev.yaml"
  done
}

lava_submit_job() {
 local job=""
 local jobId=""
 for job in `ls $SET_UP_ROOT_PATH/jobs`
 do
  logger "LAVA: Sending $SET_UP_ROOT_PATH/jobs/$job..."
  jobId=$(lavacli --uri http://$LAVA_USER:$LAVA_TOKEN@$LAVA_SERVER_IP/RPC2 jobs submit "$SET_UP_ROOT_PATH/jobs/$job")
  jobId=${jobId%%.*}
  jobId=${jobId##*"[LAVA] Job ID"}
  while ! lavacli --uri http://$LAVA_USER:$LAVA_TOKEN@$LAVA_SERVER_IP/RPC2 jobs wait "$jobId";
  do
    logger "LAVA: Waiting to finish..."
    sleep 30
  done
 done
}

