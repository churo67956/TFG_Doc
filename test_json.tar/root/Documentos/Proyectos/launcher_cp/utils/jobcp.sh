testjob_test_definition() {
   local ts;local steps
   for ts in ${!test_cases_per_ts[@]}
   do 
     steps="$steps"'    - repository:\n        metadata:\n          format: Lava-Test Test Definition 1.0\n          name: testing-test-case\n          description: first connection lava-test-case\n        run:\n          steps:\n          - export NAME='$2'\n          - export DUT='$1'\n          - export TEST_SUITES_ROOT_PATH='$LAVA_TEST_ROOT_PATH'\n          - export TEST_SUITE='"$ts"'\n          - export TEST_CASES="'"${test_cases_per_ts[$ts]:1}"'"\n          - $SHELL $TEST_SUITES_ROOT_PATH/$TEST_SUITE/main_'"$1"'\n      from: inline\n      name: '"$ts"'\n      path: inline/'$ts'.yaml\n'
   done
   echo "$steps"
}

testjob_create(){
  local duts;local dut;local ts;local tc;local job;
  local model;local job_file;
  for duts in "${!test_cases_per_duts[@]}"
  do
   echo "Creando el test job : $duts"
   unset test_cases_per_ts
   declare -A test_cases_per_ts
   for tc in ${test_cases_per_duts["$duts"]}
   do
     ts="${tc%%/*}"
     test_cases_per_ts["$ts"]+=" ${tc##*/}"
   done
   if [ $(echo "$duts" | wc -w ) -gt 1 ] 
   then
     local deploy;local boot;local test;local name
     job="job_name: Primary connection on fecha-hora.yaml\ntimeouts:\n  job:\n    minutes: 44\n  action:\n    minutes: 32\n  connection:\n    minutes: 2\n  actions:\n    lava-test-shell:\n      minutes: 20\npriority: medium\nvisibility: public\nprotocols:\n  lava-multinode:\n    roles:\n"
     for dut in $duts 
     do
       echo "Creando la seccion para el $dut"
       model=$(model_dut "$dut")
       name=$(dut_name "$model")
       job="$job      $name:\n        device_type: $name-ssh\n        count: 1\n"
       deploy="$deploy- deploy:\n    role:\n    - $name\n    to: ssh\n    os: "$(dut_os "$model")"\n"
       boot="$boot- boot:\n    role:\n    - $name\n    method: ssh\n    failure_retry: 1\n    prompts:\n    - "$(dut_prompt "$model")"\n"
       test="$test- test:\n    role:\n    - $name\n    failure_retry: 1\n    definitions:\n"$(testjob_test_definition $dut $name)
     done
     job_file="$SET_UP_ROOT_PATH/jobs/$(echo $duts | tr ' ' '_').yaml"
     echo -e "$job    timeout:\n      minutes: 18\nactions:\n$deploy$boot$test" > "$job_file"
   else
     echo "single $duts"
     model=$(model_dut "$duts")
     name=$(dut_name "$model")
     job="device_type: "$name"-ssh\njob_name: Primary connection on fecha-hora.yaml\ntimeouts:\n  job:\n    minutes: 44\n  action:\n    minutes: 32\n  connection:\n    minutes: 2\n  actions:\n    lava-test-shell:\n      minutes: 20\npriority: medium\nvisibility: public\nactions:\n- deploy:\n    to: ssh\n    os: "$(dut_os "$model")"\n- boot:\n    method: ssh\n    failure_retry: 1\n    prompts:\n    - "$(dut_prompt "$model")"\n- test:\n    failure_retry: 1\n    definitions:\n"$(testjob_test_definition $duts $name)
     job_file="$SET_UP_ROOT_PATH/jobs/0_${duts}.yaml"
     echo -e "$job" > "$job_file"
    #solo es un dispositivo
   fi
   echo "$job_file"
   #jobs="$jobs $job_file"
  done
}

testjob_submit() {
 local job;local jobId;
 for job in `ls $SET_UP_ROOT_PATH/jobs`
 do
  echo "enviando $SET_UP_ROOT_PATH/jobs/$job..."
  jobId=$(lavacli --uri http://super:$LAVA_TOKEN@192.168.12.64/RPC2 jobs submit "$SET_UP_ROOT_PATH/jobs/$job")
  jobId=${jobId%%.*}
  jobId=${jobId##*"[LAVA] Job ID"}
  while ! lavacli --uri http://super:$LAVA_TOKEN@192.168.12.64/RPC2 jobs wait "$jobId";
  do
    sleep 30
  done
 done
}

testjob_squad_submit() {
 local job;local jobId;
 for job in $jobs
 do
  jobId=$(curl 192.168.1.10:5000/api/submitjob/cargadores_ac/fusion/2011.12.02/lf1 \
     --header "Auth-Token: $SQUAD_TOKEN" \
     --form "backend=lava" \
     --form "definition=@$job")
  lavacli --uri http://super:$LAVA_TOKEN@192.168.0.10/RPC2 jobs logs "$jobId"
  #squad-admin testfetch 192.168.0.10 $jobId cargadores_ac/fusion
 done
}
