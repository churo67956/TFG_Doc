lava_create_devices(){
 local model
 while [ $# -gt 0 ]
 do
  model=$(collection_get_model duts HW_VERSION=$1)
  if ! ( lava-server manage device-types list | tr '\n' ' ' |  grep $1-ssh ) 
  then
    echo -e "$DEVICE_TYPE_TEMPLATE" > $LAVA_TEMPLATE_ROOT_PATH/device-types/$1-ssh.jinja2
    chown lavaserver:lavaserver $LAVA_TEMPLATE_ROOT_PATH/device-types/$1-ssh.jinja2
    if ! lava-server manage device-types add $1-ssh>/dev/null
    then
      logger "LAVA: Unable to load $1-ssh device"
      return 1
    fi
  fi
  if ! ( lava-server manage devices list | tr '\n' ' ' | grep $1 )
  then
    echo -e "{% extends '"$1"-ssh.jinja2' %}\n{% set ssh_host = ssh_host | default('"$(model_get IP $model)"') %}\n{% set ssh_identity_file = 'dynamic_vm_keys/lava' %}"  > "$LAVA_TEMPLATE_ROOT_PATH/devices/$1.jinja2"
    chown lavaserver:lavaserver "$LAVA_TEMPLATE_ROOT_PATH/devices/$1.jinja2"
    if ! ( lava-server manage devices add --device-type "$1-ssh" --worker  $(model_get WORKER $model) $1>/dev/null  )
    then
       logger "LAVA: Unable to add $1 device"
       return 1
    fi
    if ! ( lava-server manage devices update --health GOOD $1>/dev/null ) 
    then
      logger "LAVA: Unabe to update $1 device heath"
      return 1
    fi
  fi
  shift
 done
}

lava_submit_job(){
  local job=""
  local jobId=""
  local model=""
  local tsc=""
  local tsp=""
  local tcl=""
  local tcps=$(echo -e $* | awk -F '|' '{print $1}' | sort)
  local devs=$(echo -e $* | awk -F '|' '{print $2}' | sort)
  lava_create_devices $devs || return 1
  for dev in $devs
  do
    model=$(collection_get_model duts HW_VERSION=$dev)
    job="device_type: "$dev"-ssh
job_name: Primary connection on fecha-hora.yaml
timeouts:
  job:
    hours: 8
  action:
    hours: 8
  connection:
    hours: 2
  actions:
    lava-test-shell:
      hours: 6
priority: medium
visibility: public
actions:
- deploy:
    to: ssh
    os: "$(model_get OS $model)"
- boot:
    method: ssh
    failure_retry: 1
    prompts:
    - "$(model_get PROMPT $model)"
- test:
    failure_retry: 1
    definitions:"
    for tcp in $tcps
    do
      tsc=$(echo "$tcp" | awk -F '/' '{print $(( NF - 1 ))}')
      case `ls $tcp` in
      *"$dev"*)
         case "$tsc" in
         "$tsp") #same test suite
           tcl="$tcl "$(echo "$tcp" | awk -F '/' '{print $NF }')
         ;;
         *) #new test suite
           if [ -n "$tcl" ]
           then
             job="$job"'
          - export TEST_CASES="'"$tcl"'"
          - $SHELL $TEST_SUITES_ROOT_PATH/$TEST_SUITE/main_'"$dev"'
      from: inline
      name: '"$tsp"'
      path: inline/'$tsp'.yaml'
           fi
           job="$job"'
    - repository:
        metadata:
          format: Lava-Test Test Definition 1.0
          name: testing-test-case
          description: first connection lava-test-case
        run:
          steps:
          - export DUT='$dev'
          - export TEST_SUITES_ROOT_PATH='$LAVA_TEST_ROOT_PATH'
          - export TEST_SUITE='"$tsc"''
           tcl=$(echo "$tcp" | awk -F '/' '{print $NF }')
           tsp="$tsc"
         ;;
         esac
      ;;
      esac
    done
    if [ -n "$tcl" ]
    then
      job="$job"'
          - export TEST_CASES="'"$tcl"'"
          - $SHELL $TEST_SUITES_ROOT_PATH/$TEST_SUITE/main_'"$dev"'
      from: inline
      name: '"$tsp"'
      path: inline/'$tsp'.yaml'
    fi
    echo  "$job" > "$SET_UP_ROOT_PATH/jobs/0_$dev.yaml"
    tcl=""
    tsp=""
  done
  for job in `ls $SET_UP_ROOT_PATH/jobs`
  do
   logger "LAVA: Sending $job..."
   jobId=$(lavacli --uri http://$LAVA_USER:$LAVA_TOKEN@$LAVA_SERVER_IP/RPC2 jobs submit "$SET_UP_ROOT_PATH/jobs/$job")
   jobId=${jobId%%.*}
   jobId=${jobId##*"[LAVA] Job ID"}
   while ! lavacli --uri http://$LAVA_USER:$LAVA_TOKEN@$LAVA_SERVER_IP/RPC2 jobs wait "$jobId"
   do
    logger "LAVA: Waiting to finish..."
    sleep 30
   done
  done
}


