
#input parametes are the keys
#collection_file=/root/Documentos/Proyectos/launcher_cp/configs/duts.js
#collection_raw=$(cat "$collection_file" | jq)
#collection_size=$(echo "$collection_raw" | jq length)
#collection_name="dut"
#keys=$( echo "$collection_raw" | jq .[0] | jq keys | xargs echo )

collection_get_model(){
 local phase="select("
 local key
 local value
 case "$1" in
  duts)
    collection_raw=$(cat $SET_UP_ROOT_PATH/configs/duts.json)
  ;;
  *)
   return 1
  ;;
 esac
 shift
 while [ $# -gt 0 ]
 do
   case "$1" in
    *=*) 
      key=$(echo "$1" | awk -F"=" '{print $1}')
      value=$(echo "$1" | awk -F"=" '{print $2}')
      phase=$phase'.'$key'=="'$value'" && '
      shift
    ;;
    *)
      shift
    ;;
   esac
 done
 phase=${phase::-3}')'
 echo "$collection_raw" | jq .[] | jq "$phase"
}

model_get(){
 local key="$1"
 shift 
 echo $* | jq .$key | xargs echo
}

load_model(){
 local collection_name=$1
 shift
 local model_id=$1
 shift
 while [ $# -gt 0 ]
 do
   case "$1" in
    '['|']')
      shift
    ;;
    *,) 
      eval "$collection_name"_"$model_id"_${1::-1}='"'$(echo "$collection_raw" | jq .[$model_id] | jq .${1::-1} | xargs echo)'"'
      shift
    ;;
    *)
      eval "$collection_name"_"$model_id"_${1}="$(echo "$collection_raw" | jq .[$model_id] | jq .${1} | xargs echo)"
      shift
    ;;
   esac
 done
}

load_models(){
 local collection_name=$1
 shift
 local collection_size=$1
 shift
 local counter=0
 while [ $counter -lt $collection_size ]
 do
   load_model "$collection_name" "$counter" $*
   counter=$(( counter + 1 ))
   break
 done
}

print_model(){
 local collection_name=$1
 shift
 local id=$1
 shift
 while [ $# -gt 0 ]
 do
   case "$1" in
    '['|']')
      shift
    ;;
    *,) 
      eval echo "${1::-1}"='$'"$collection_name"_"$id"_"${1::-1}"
      shift
    ;;
    *) 
      eval echo "${1}"='$'"$collection_name"_"$id"_"${1}"
      shift
    ;;
   esac
 done 
}

print_models(){
 local collection_name=$1
 shift
 local collection_size=$1
 shift
 local counter=0
 while [ $counter -lt $collection_size ]
 do
   print_model $collection_name $counter $*
   counter=$(( counter + 1 ))
   break
 done
}


#find_model "$collection_raw" HW_VERSION=\"HW_FUSION_MM\" 
#load_models "$collection_name" "$collection_size" $keys
#print_models "$collection_name" "$collection_size" $keys
