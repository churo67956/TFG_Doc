import sys
import argparse
import simplejson
import datetime
import uuid
import zmq
from zmq.utils.strtypes import b

#https://lkft.validation.linaro.org/static/docs/v2/advanced-installation.html?highlight=ipc%20tmp%20lava%20events
#trigger function used by jenkisn
#lava-server manage diffsettings

EVENT_TOPIC="ingeteam.evci.launcher"
INTERNAL_EVENT_SOCKET="ipc:///tmp/lava.events"
USER="jenkins"

class BuildPublisherError(Exception):
	 """ Raise an BuildPublisherError """

class BuildPublisher:
	def __init__(self):
		self.context = zmq.Context.instance()
		self.socket = self.context.socket(zmq.PUSH)
		self.socket.connect(INTERNAL_EVENT_SOCKET)

	def send_event(self,data):
		try:
			# The format is [topic, uuid, datetime, username, data as json]
			msg = [
				b(EVENT_TOPIC),
				b(str(uuid.uuid1())),
				b(datetime.datetime.utcnow().isoformat()),
				b(USER),
				b(simplejson.dumps(data)),
			]
			print(msg)
			# Send the message in the non-blockng mode.
			# If the consumer (lava-publisher) is not active, the message will be lost.
			self.socket.send_multipart(msg, zmq.DONTWAIT)
		except (TypeError, ValueError, zmq.ZMQError):
			raise BuildPublisherError("Unable to send the zmq event %s" % EVENT_TOPIC)
		# The event can't be send, just skip it

def main():
	parser = argparse.ArgumentParser()
	parser.add_argument("-rc", "--rc", required=True, help="Test link project name")	
	options = parser.parse_args()
	publisher = BuildPublisher()	
	publisher.send_event({"rc":options.rc})
	
if __name__ == "__main__":
    main()
