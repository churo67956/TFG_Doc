#find a test cases of the test cases root path
#$* list of test cases
#return a list of devices and the full path of the test cases
test_cases_check(){
  local hw_version=$1
  shift
  local tc=""
  local tcp=""
  local str=""
  local device=""
  local devices=""
  local x=0
  while [ $# -gt 0 ]
  do
    case "$1" in
    [|])
      shift
      continue
    ;;
    *,)
      tc=${1::-1}
    ;;
    *)
      tc=$1
    ;;
    esac
    str="$(find $TEST_SUITES_ROOT_PATH/$hw_version -name $tc -type d)"
    if [ -z "$str" ] || [ $( echo "$str" | wc -l ) -gt 1 ]
    then
      logger "LAVA: Just one test case root path is needed for $tc. More info $str" 
      return 1
    fi
    #check 
    if [ $( echo ${str:$(( ${#TEST_SUITES_ROOT_PATH} + ${#hw_version})):$((${#str}- ${#TEST_SUITES_ROOT_PATH} - ${#hw_version}))} | awk -F / '{print NF}' ) -ne 3 ]
    then
      logger "LAVA: Check $tc scaffolding.TESTSUITEROOT>TESTSUITE_NAME>TESTCASE_NAME"
      return 1
    fi
    #check platform
    device=$( ls "$str" | grep HW ) 
    if [ $? -ne 0 ] || [ $(echo "$device" | wc -l ) -ne 1 ]
    then
      logger "LAVA: Just one platform needed for $1"
      return  1
    else
     devices=$devices'\n'"$device" 
    fi
    tcp="$tcp"'\n'"$str"
    shift
  done
  #return test case
  devices=$(echo -e "$devices" | uniq)
  tcp=$(echo -e "$tcp" | sort )
  echo -e "${tcp:1}|${devices:1}"
}

 
test_cases_deploy(){
 local hw_version=$1
 shift
 local tc=""
 local tsc=""
 local tsp=""
 local devs=$(echo $* | awk -F '|' '{print $2}' ) 
 local tcps=$(echo $* | awk -F '|' '{print $1}' )
 local model=""
 for dev in $devs
 do
  #echo 1-$dev
  command="tar -zcvf $TAR_ROOT_PATH/$dev.tar.gz -C $TEST_SUITES_ROOT_PATH/$hw_version"
  for tcp in $tcps
  do
    #echo 1-"$tcp"
    #check that the test case has the device
    case `ls $tcp` in
    *$dev*)
      #select the test suite
      tsc=$(echo "$tcp" | awk -F '/' '{print $((NF - 1)) }')
      tc=$(echo "$tcp" | awk -F '/' '{print $NF }')
      command="$command $tsc/$tc"
      case "$tsc" in
      "$tsp")
        #same test suite
        true
      ;;
      *) #change test suite tar the reserved paths
        command="$command $tsc/utils $tsc/utils_$dev $tsc/main_$dev"
        [ -d "$TEST_SUITES_ROOT_PATH/$tsc/utils" ] || mkdir -p "$TEST_SUITES_ROOT_PATH/$tsc/utils"
        [ -d "$TEST_SUITES_ROOT_PATH/$tsc/utils_$dev" ] || mkdir -p "$TEST_SUITES_ROOT_PATH/$tsc/utils_$dev" 
        [ -f "$TEST_SUITES_ROOT_PATH/$tsc/main_$dev" ] || echo ""  >> "$TEST_SUITES_ROOT_PATH/$tsc/main_$dev"
        tsp=$tsc
      ;;
      esac
      #tar the test case path
    ;;
    esac
  done
  $command || ( logger "LAVA: Unable to create the tarball for dut $dev" && return 1 )
  logger "LAVA: Tarball for $dut created correctly"
  model=$(collection_get_model duts HW_VERSION=$dev) 
  scp -i $SET_UP_ROOT_PATH/.ssh/lava $TAR_ROOT_PATH/$dev.tar.gz $(model_get USER $model)@$(model_get IP $model):/tmp  || ( logger "LAVA: Unable to deploy the tarball for dut $dev" && return 1)
  ssh -i $SET_UP_ROOT_PATH/.ssh/lava $(model_get USER $model)@$(model_get IP $model) "mkdir -p $LAVA_TEST_ROOT_PATH && tar -xzf /tmp/$dev.tar.gz -C $LAVA_TEST_ROOT_PATH" || ( logger "LAVA: Unable to untar the tarball for dut $dev" && return 1 )
  logger "LAVA: Tarball for $dut deployed correctly"
  tsp=""
 done
 return 0
}

