publisher(){
 local rc=$?
 /bin/python3  $SET_UP_ROOT_PATH/utils/raw_publisher.py --rc $rc 
}


